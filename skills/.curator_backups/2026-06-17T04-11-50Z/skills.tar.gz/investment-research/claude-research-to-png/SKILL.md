---
name: claude-research-to-png
description: Run investment research via Claude Code (with serenity-skill + serenity-value), capture the full output, render as a beautiful HTML infographic, and convert to PNG for sharing. Trigger on requests like "用 serenity 深度调研", "用 Claude 研究", "生成研究长图", or user references to serenity-value/serenity-skill research tasks.
license: MIT
metadata:
  author: user-custom
  version: "1.0.0"
---

# Claude Code Research → PNG 输出

Run deep investment research through Claude Code with serenity-skill/serenity-value, then render the complete output as a shareable PNG infographic.

## Workflow

### 1. Write prompt to temp file

```
write_file(path="/tmp/serenity-prompt.txt", content="<full Chinese research prompt>")
```

Prompt template:
```
用最新的 serenity-value 深度调研现在 [市场] [产业链主题]。
请联网查公告、财报、问询函、互动易、招投标、环评/能评、专利、客户认证和财务质量，
先排产业链层级，再找 [N] 个最值得优先研究的标的，
并说明卡住的环节、产业链位置、证据、排序理由和主要风险。
输出用中文。
```

### 2. Run Claude Code with Opus (background)

```
terminal(
  background=true,
  notify_on_complete=true,
  timeout=600,
  command='export HTTP_PROXY="http://127.0.0.1:7897" HTTPS_PROXY="http://127.0.0.1:7897" && claude -p "$(cat /tmp/serenity-prompt.txt)" --model opus --max-turns 30 --allowedTools "Read,WebSearch,WebFetch,Bash" --output-format text --verbose 2>&1'
)
```

### 3. Wait for completion, read full output

```
process(action="log", session_id="<id>", limit=500)
```

### 4. Render to HTML infographic

Create a dark-themed HTML card (`~161b22` background, `#f0c040` gold accents, `#c9d1d9` text) that mirrors the research structure:

- **Header**: title, date, source count badges
- **Section 1**: Demand background (the "why now")
- **Section 2**: Value chain layer ranking with tier labels
- **Section 3**: Each stock with: name/ticker, bottleneck descriptor, evidence (green), ranking rationale, risks (red), and the `📊 卡脖子强度 | 估值 | 吸引力 ★` summary line
- **Section 4**: Stocks excluded and why
- **Section 5**: What could prove the thesis wrong
- **Section 6**: Next verification steps
- **Section 7**: Synthesis judgment
- **Footer**: disclaimer

Style rules: 14px base, 1.8 line-height, PingFang SC font stack, bordered cards, no external dependencies.

### 5. Render HTML → PNG via Playwright + Edge

```python
from playwright.sync_api import sync_playwright

html_path = r"C:\Users\Administrator\Desktop\研究标题.html"
png_path = r"C:\Users\Administrator\Desktop\研究标题.png"

with sync_playwright() as p:
    browser = p.chromium.launch(channel="msedge", headless=True)
    page = browser.new_page(viewport={"width": 800, "height": 600})
    page.goto(f"file:///{html_path.replace(chr(92), '/')}", wait_until="networkidle")
    full_height = page.evaluate("document.body.scrollHeight")
    page.set_viewport_size({"width": 800, "height": full_height})
    page.screenshot(path=png_path, full_page=True)
    browser.close()
```

### 6. Deliver to user

Include `MEDIA:C:\Users\Administrator\Desktop\研究标题.png` in the response, or send via `send_message`.

## Pitfalls

- **Opus is slow**: First response can take 5-10 minutes. Print mode buffers all output — no progress is visible until complete. Tell the user it's running and will deliver when done.
- **Don't switch models without asking**: Never change from Opus to Sonnet (or vice versa) mid-task without explicit user approval.
- **Playwright chromium download fails in China**: Use `channel="msedge"` to leverage system Edge browser instead of downloading Chromium.
- **Memory near limit**: Before long research tasks, check memory usage — compact if needed.
- **Prompt file**: Always write the prompt to `/tmp/serenity-prompt.txt` first to avoid shell quoting issues with Chinese characters.
