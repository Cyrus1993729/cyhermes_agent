# PNG 渲染（Playwright + 系统 Edge）

Windows 环境下使用系统自带 Edge 浏览器，无需额外下载 Chromium（国内网络下载经常失败）。

## 依赖

```bash
pip install playwright
# 无需 playwright install chromium
```

## 渲染脚本

```python
from playwright.sync_api import sync_playwright

html_path = r"C:\Users\Administrator\Desktop\存储产业链完整研究.html"
png_path = r"C:\Users\Administrator\Desktop\存储产业链完整研究.png"

with sync_playwright() as p:
    browser = p.chromium.launch(channel="msedge", headless=True)
    page = browser.new_page(viewport={"width": 800, "height": 600})
    page.goto(f"file:///{html_path.replace(chr(92), '/')}", wait_until="networkidle")
    
    full_height = page.evaluate("document.body.scrollHeight")
    page.set_viewport_size({"width": 800, "height": full_height})
    page.screenshot(path=png_path, full_page=True)
    browser.close()

import os
print(f"Size: {os.path.getsize(png_path)/1024/1024:.1f} MB, Height: {full_height}px")
```

## 注意

- `channel="msedge"` 使用系统 Edge，国内无需翻墙下载
- 文件路径反斜杠 `\` 需替换为 `/`
- `full_page=True` 一次性截取完整长图
- HTML 所有 CSS/字体必须内联，不依赖外部 CDN
