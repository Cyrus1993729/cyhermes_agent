---
name: claude-code-workflow
description: User-specific workflow rules for orchestrating Claude Code via Hermes Agent. Covers model selection protocol, progress reporting, and action-confirmation requirements. Load alongside claude-code skill whenever delegating tasks to Claude Code.
license: MIT
compatibility: Hermes Agent → Claude Code CLI
metadata:
  author: user-custom
  version: "1.0.0"
---

# Claude Code Workflow Rules

User-specific rules for how Hermes Agent should orchestrate Claude Code. These rules apply every time Claude Code is invoked, regardless of the task.

## Rule 1: Model Selection Protocol

**CRITICAL — never change the model without explicit user approval.**

- If the user specifies a model (e.g., "用 Opus 跑"), use exactly that model. Do not downgrade or switch.
- If the first run with the user's chosen model appears slow or produces no output, do NOT silently switch to a faster model (Sonnet, Haiku, etc.). Instead:
  1. Wait a reasonable time (at least 5 minutes for deep research tasks)
  2. Report the status to the user
  3. ASK the user whether they want to continue waiting, switch models, or try another approach
- The user may have reasons for choosing a specific model (deeper reasoning, different strengths) that the agent should not override.

## Rule 2: Action Confirmation Protocol

**CRITICAL — confirm the approach before executing, especially for modifications.**

- Before making ANY change to files, configuration, installed skills, or running any action that has side effects, state the plan and ask for confirmation.
- This includes but is not limited to:
  - Modifying skill files (even user-created ones)
  - Changing Claude Code flags or parameters
  - Installing or removing software
  - Modifying project configuration
- The only exception is when the user explicitly says "just do it" or equivalent.

## Rule 3: Progress Reporting During Long Tasks

**CRITICAL — provide periodic status updates during long-running tasks.**

- When Claude Code is running a deep research task (web searches, multiple turns), check progress every 2-3 minutes.
- Report to the user:
  - That the task is still running
  - How long it has been running
  - Any visible progress (e.g., "first turn complete, now searching")
- If the task has been running with zero visible output for >5 minutes, flag this to the user and ask how to proceed.
- Do NOT leave the user wondering whether the task is alive or dead.

## Rule 4: Skill Modification Protection

**Do not modify installed skills without explicit user permission.**

- Skills installed from external sources (like serenity-skill from GitHub) represent the author's methodology. The user has chosen to use them as-is.
- If the user wants to extend a skill's behavior, create a NEW companion skill rather than modifying the original.
- If a modification is accidentally made, revert it immediately when the user objects.

## Bundled Resources

- `references/cyclical-valuation-pitfalls.md` — valuation methodology pitfalls for cyclical stocks (semiconductors, storage, energy). Load when doing investment research on cyclical sectors.
