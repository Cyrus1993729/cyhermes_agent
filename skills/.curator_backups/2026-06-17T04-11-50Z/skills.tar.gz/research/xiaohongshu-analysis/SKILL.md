---
name: xiaohongshu-analysis
description: 小红书内容理解流水线 — 用户发分享链接，自动提取图文/视频内容并生成结构化分析报告。支持零人工介入的 ad-hoc 分析。
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [xiaohongshu, rednote, analysis, pipeline, asr, ocr, vision]
---

# 小红书内容分析

用户发小红书分享链接 → 自动提取内容 → 结构化分析报告。零人工介入。

## 支持的内容类型

| 类型 | 处理方式 |
|:---|:---|
| 图文帖子 | 下载图片 → Vision 识图 → DeepSeek 总结 |
| 视频帖子 | 下载视频 → ASR（faster-whisper）+ OCR（RapidOCR）→ DeepSeek 总结 |

## 使用方式

```
用户发来小红书分享链接（含 xhslink.com 短链或完整 URL）
  → 自动解析 → 提取内容 → 输出分析报告
```

触发条件：用户消息中包含 `xhslink.com` 链接 或 `xiaohongshu.com` 链接，且表达了分析/理解的意图。

## 架构

```
[xhslink.com 短链]
    ↓ HTTP 302 重定向（保留 xsec_token）
[xiaohongshu.com 真实笔记页]
    ↓ HTML 解析 __INITIAL_STATE__（修复 JS undefined→null）
[标题 / 正文 / 图片URL / 视频URL / 互动数据]
    ↓
    ├── 图文帖 → 下载图片 → Vision 识图 → DeepSeek 总结
    └── 视频帖 → 下载视频 → ffmpeg 抽音频+抽帧
                    ├── faster-whisper tiny (auto, chunked 120s)
                    ├── pHash 去重 + RapidOCR
                    └── DeepSeek 整合总结
```

## 关键实现细节

### JSON 解析修复
`__INITIAL_STATE__` 包含 JS 的 `undefined` 值（非 JSON 合法），解析前需：
```python
import re
json_str = re.sub(r':\s*undefined', ':null', json_str)
```

### 视频下载
- 视频 URL 在 `note.video.media.stream.h264[0].masterUrl`
- 请求必须带 `Referer: https://www.xiaohongshu.com/`
- 住宅 IP 无需 cookie，数据中心 IP 可能触发验证码

### 音频分块
- faster-whisper 不支持 `start`/`duration` 参数
- 需用 ffmpeg `-f segment -segment_time 120` 物理切片，再逐段转录

### 进度监控
- 不使用 `terminal(background=true)` — Python stdout 完全缓冲
- 使用 `terminal(foreground)` + 文件重定向
- 通过缓存文件检查进度：`asr.json` → `ocr.json` → `summary.json`

## 缓存

`~/.hermes/cache/xhs-pipeline/<note_id>/`

步骤文件：
- `meta.json` — 解析后的帖子元数据
- `video.mp4` — 下载的视频（如有）
- `audio.wav` — 提取的音频
- `asr.json` — 语音转录结果
- `frames/` — 抽取的帧
- `ocr.json` — 画面 OCR 结果
- `images/` — 图文帖的图片
- `summary.json` — 最终分析报告

## 依赖

- Python 3.11+: faster-whisper, rapidocr-onnxruntime, imagehash, Pillow, openai
- ffmpeg: imageio-ffmpeg 自带（`imageio_ffmpeg.get_ffmpeg_exe()` 获取路径）
- DeepSeek API key: `C:\Users\Administrator\deepseek_key.txt`

## 代理

小红书国内 CDN 直连，不需要代理。DeepSeek API 也不需要代理。全程不走代理。

## 已知限制

| 限制 | 说明 |
|:---|:---|
| 登录墙 | 部分帖子需要登录才能看，需提供 cookie（未来版本） |
| 视频时效 | CDN URL 带 sign 参数有时效，下载需在获取后尽快完成 |
| 评论 | 网页版评论需登录，当前版本不抓评论 |
| ASR 精度 | faster-whisper tiny 模型中文识别有误差，关键内容 OCR 可校正 |

## 输出格式

```markdown
# 小红书内容分析报告

## 📋 帖子信息
（标题、作者、互动数据等）

## 一、内容概览
（一句话概括）

## 二、核心内容
（2-3 个要点）

## 三、详细分析
（视频：ASR+OCR 整合 / 图文：Vision 识图）

## 四、关键观点/结论
（提取的核心论点）

## 五、价值评估
（实操价值、可复刻性、适合人群）

## 🔧 技术复盘
（步骤耗时、成本）
```

## 验证测试

| 帖子 | 类型 | 时长 | ASR | OCR | 成本 |
|:---|:---|:---|---:|:---:|---:|
| 6a2f394e000000002102170b | 视频 | 364s | ✅ (87 seg) | ✅ (16帧) | ¥0.022 |
