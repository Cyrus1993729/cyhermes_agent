---
name: data-pipeline-builder
description: "Build data-driven scoring, analysis, and reporting systems in Python — research → framework → data validation → modular build → iterate."
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [data-pipeline, scoring-system, python, financial-data, etl, reporting]
    related_skills: [jupyter-live-kernel]
---

# Data Pipeline Builder

Build automated data-pull → scoring → report systems in Python. Used for financial analysis, monitoring dashboards, KPI scorecards, and any system that fetches data, runs through a scoring model, and outputs structured reports.

## When to Use

- Building any quantitative scoring/rating system (financial, operational, quality)
- Creating automated data-fetch → analyze → report pipelines
- Systems with multiple data sources and fallback strategies
- User asks for a "model," "scoring system," or "analysis pipeline"

## The Pattern (7 Steps)

### 1. Domain Research (delegate_task)

Use `delegate_task` to research the domain before building:
- Best indicators / model architectures
- Industry-standard thresholds and parameters
- Available free data sources

**Pitfall**: Delegate research AND data-source research as separate parallel tasks. If data-source research times out (600s), handle it yourself with direct knowledge.

### 2. Present Framework for Approval

Before writing code, present the framework to the user:
- Architecture diagram (modules + weights + thresholds)
- Data source list with feasibility assessment
- Signal synthesis logic

**User preference discovered**: Some users want to evaluate the framework BEFORE you build anything. Don't skip to implementation. Present the model, let them critique, iterate on the design.

### 3. Validate Data Sources (SMOKE TEST FIRST)

**This is the most important step.** Before building the full system, verify each data source works:

```bash
python -c "
from data_fetcher import DataFetcher
f = DataFetcher()
print('gold:', 'OK' if f.fetch_gold_price() is not None else 'FAIL')
print('tips:', 'OK' if f.fetch_tips_yield() is not None else 'FAIL')
"
```

Classify results: ✅ working, ⚠️ needs config, ❌ broken. Fix data issues before building scorers.

### 4. Modular Build

Project structure:
```
project/
├── config.py          # Weights, thresholds, tickers, paths
├── data_fetcher.py    # One class, one method per source
├── module_a.py        # Scorer class per dimension
├── module_b.py        # Each returns (score, breakdown_dict)
├── scorer.py          # Composite engine + regime detection
├── main.py            # Entry point + report formatting
└── requirements.txt
```

**Rule**: Each scoring module MUST return `Tuple[float, Dict]` — (score, breakdown). The breakdown dict contains per-sub-component scores for debugging/reporting.

### 5. Iterative Fix (expect data issues)

Common data-pipeline gotchas — see `references/python-financial-data-sources.md` for details. Key ones:

| Problem | Fix |
|---------|-----|
| yfinance rate-limited | Use `yf.Ticker(ticker, session=session).history()` NOT `yf.download()` |
| akshare Chinese columns | Column names like `交易时间`/`早盘价` need explicit mapping |
| FRED no data | Requires free API key from fred.stlouisfed.org |
| Cache timezone mismatch | `pd.to_datetime(index, utc=True)` then strip tz |
| Empty DataFrame = rate limit | yfinance returns empty (not exception) on rate limit → retry |
| `safe_last` duplicated in 6 files | Extract to `utils.py` immediately. Every module redefining the same 3-line helper is technical debt that causes drift bugs |
| Cross-ETF volume misalignment | `pd.concat([etf1_vol, etf2_vol], axis=1).sum(axis=1)` not naive `vol1 + vol2` — different date indices silently produce NaN

### 6. Composite Scoring Engine

```python
class Scorer:
    def __init__(self):
        self.module_a = ModuleAScorer()
        self.module_b = ModuleBScorer()
        self.regime = RegimeDetector()

    def run(self, data):
        regime = self.regime.detect(data)
        weights = adjust_weights(base_weights, regime)
        scores = {m: s.score(data) for m, s in self.modules.items()}
        composite = sum(s * weights[m] for m, s in scores.items())
        return composite, scores, regime
```

**Regime detection**: Use IF-THEN rules with scoring (not hard classification). Each regime gets a score; highest wins. Default to "mixed" when no signal is strong.

### 7. Report Generation

- Console output: formatted text with bars, emojis, Chinese labels
- **Signal explanations**: Every bullish/bearish signal in the report MUST carry a human-readable explanation with actual data values, not just a label. Build a `_explain_signal()` engine that maps each scoring component to a contextual sentence embedding key numbers (e.g., "TIPS实际收益率 2.07%，处于上升趋势，压制黄金" not "real_yield: -2.0").
- **User-facing 0-100 scale**: Internal scores stay in [-2, +2] for math consistency, but user-facing display converts to 0-100 (`(score+2)/4*100`) for intuitive readability.
- JSON output: full breakdown for programmatic use
- Save to file for cron job consumption

## Scoring Architecture Best Practices

**Weighted dimensions**: Each dimension gets a float weight. Weights MUST sum to 1.0. Regime detection can shift weights ±5%.

**Threshold scoring**: Use `apply_threshold(value, [(low, high, score), ...])` pattern. Edge case: handle values exactly at boundaries by using `low <= value < high`.

**Clamp everything to [-2, +2]**: Every module, every sub-component, and the final composite all live in the same range. This makes scores comparable across dimensions.

**Missing data = score 0**: When a data source is unavailable, the sub-component scores 0 (neutral). Don't fail. Don't guess. Log the gap.

**Breakdown format**:
```python
{
    "module": "macro",
    "composite": 0.6,
    "items": [
        ("component_name", weight, score, {detail_dict}),
        ...
    ]
}
```

## Tips

- **Always smoke-test data sources before building scorers** — data issues are the #1 cause of rework
- **Use `delegate_task` for research, not implementation** — subagents time out on large code tasks. For implementation, either do it yourself or use Claude Code CLI
- **Cache everything** — yfinance, FRED, and akshare all benefit from 1-day CSV caching. Disk I/O is free; API rate limits are not
- **Session-based yfinance** — create one `requests.Session()` with a real User-Agent header and reuse it across all `yf.Ticker()` calls
- **Signal damping across runs** — save composite score to JSON each run. On direction change, dampen by blending with previous (e.g., `composite * 0.7 + prev * 0.3`) to avoid whipsaw. Track consecutive same-direction runs to let confirmed signals through.
- **Cross-source data alignment** — when combining volume/shares from multiple ETFs or data sources with different date indices, use `pd.concat([s1, s2], axis=1).sum(axis=1).dropna()` instead of naive addition. Mismatched dates silently produce wrong totals.
- **Config file, not env vars** — for non-sensitive settings (tickers, thresholds, paths), hardcode in config.py for simplicity. **Sensitive keys (API keys, tokens) MUST go in environment variables** (`FRED_API_KEY`, etc.) and be referenced from config via `os.environ.get()`. Never hardcode credentials.

## Further Reading

- `references/python-financial-data-sources.md` — yfinance, akshare, fredapi pitfalls and workarounds
