---
name: bilibili-food-research
description: >
  Research B站 (Bilibili) food/travel review videos to extract restaurant
  recommendations for a specific location. Covers searching for videos,
  filtering by creator and location, extracting store names, addresses,
  prices, signature dishes, and reviews from comments + danmaku, then
  looking up addresses via OSM.
trigger: >
  When the user asks for food/travel recommendations based on a specific
  B站 video creator (e.g., "刘雨鑫的大连探店", "从XX博主的视频里找某地美食").
  Also triggers when the user wants Chinese restaurant intel extracted
  from video platforms.
---

# B站美食探店研究

从B站美食博主视频中提取餐厅推荐，整理成包含店名、地址、价格、评价的攻略。

## 工作流程

### 1. 找到博主UID

```
搜索API: https://api.bilibili.com/x/web-interface/search/type?search_type=bili_user&keyword=<博主名>
```

### 2. 搜索目标地点的视频

```
https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=<博主>+<地点>
```

⚠️ **PITFALL**: 一个地点博主可能拍了多个视频（不同角度/不同店）。标题里没写地名的视频可能在tag里有。要多轮不同关键词搜索，不要漏。

### 3. 获取视频详情

```
https://api.bilibili.com/x/web-interface/view?bvid=<BV>
https://api.bilibili.com/x/web-interface/view/detail?bvid=<BV>
```

关键字段：`aid`(用于评论), `cid`(用于弹幕), `ugc_season`(合集信息)

### 4. 挖掘评论区和子回复 ⭐

这是**最有价值的信息源**。店名、地址、价格几乎全在评论区。

```
热门评论: https://api.bilibili.com/x/v2/reply/main?oid=<aid>&type=1&mode=3&ps=20
子回复: https://api.bilibili.com/x/v2/reply/reply?oid=<aid>&type=1&root=<rpid>&ps=10
```

子回复（楼中楼）是金矿——观众会在子回复里问"在哪""店名叫什么"，也经常有人回答。

### 5. 弹幕分析

弹幕包含实时价格判断和真实性验证。

```python
from bilibili_api import video
v = video.Video(bvid=bvid)
dms = await v.get_danmakus(page_index=0)
```

或用 `you-get` 下载弹幕XML。

### 6. 地址查找

OSM Nominatim（需要代理）:
```
https://nominatim.openstreetmap.org/search?q=<关键词>+<城市>&format=json&accept-language=zh
```

对于中国地址，OSM覆盖有限。优先使用评论区提取的地址线索。

### 7. 输出格式

整理成：
- 店名、具体位置、到达方式
- 特色菜、参考价格
- 博主评价 + 弹幕/评论共识
- 实用Tips（周边、时间、支付方式等）
- 附B站视频链接

使用中文输出，面向终端消费者（非技术用户）。

## 工具链

| 工具 | 用途 |
|------|------|
| B站 search API | 搜索视频/用户 |
| B站 view/detail API | 视频元数据 |
| B站 reply API | 评论+子回复 |
| `bilibili-api` (Python) | 弹幕获取 |
| `you-get` | 视频/弹幕下载 |
| OSM Nominatim | 地址地理编码 |

## API请求头

```python
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Referer": "https://www.bilibili.com/",
    "Origin": "https://www.bilibili.com",
}
```

B站有时返回412风控。出现时等几秒重试，或换用不同的搜索词/API端点。

## 常见坑

1. **搜不全**：博主可能用不同标题格式（"辽宁大连" vs "大连" vs "东北"），多轮搜索
2. **描述为空**：视频描述字段几乎总是空的，不要依赖
3. **店名不在标题里**：90%的店名信息在评论区，不是视频元数据
4. **字幕不可用**：大部分视频没有AI字幕，需要登录才能获取
