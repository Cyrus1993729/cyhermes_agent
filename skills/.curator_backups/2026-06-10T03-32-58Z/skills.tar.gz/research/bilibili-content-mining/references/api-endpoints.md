# B站 API 端点速查

## 已验证可用的端点（无需登录）

### 搜索
- `GET https://api.bilibili.com/x/web-interface/search/all/v2?keyword=XX`
  - 返回分类结果（video/user/article等），比 search/type 更稳定
- `GET https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=XX&page=1`
  - 直接返回视频结果，间歇性412

### 视频
- `GET https://api.bilibili.com/x/web-interface/view?bvid=BVXXX`
  - 基础信息：title, desc(常空), aid, cid, duration, stat
- `GET https://api.bilibili.com/x/web-interface/view/detail?bvid=BVXXX`
  - 含View + Related + Tags + ugc_season

### 评论
- `GET https://api.bilibili.com/x/v2/reply/main?oid=AID&type=1&mode=3&ps=20`
  - mode=3 按热度排序
- `GET https://api.bilibili.com/x/v2/reply/reply?oid=AID&type=1&root=RPID&ps=10`
  - 楼中楼子回复，地址信息的金矿

### 需登录
- `ai_conclusion`: 需要 sessdata
- `space/wbi/arc/search`: 需要 WBI 签名

### 弹幕
- 通过 bilibili-api-python 库的 `video.Video.get_danmakus()` 获取
- 弹幕XML：`https://api.bilibili.com/x/v1/dm/list.so?oid=CID`

## Headers 模板

```python
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Referer": "https://www.bilibili.com/",
    "Origin": "https://www.bilibili.com",
}
```

## 风控应对

- 412错误 → 换端点（search/all/v2 替代 search/type）
- 间歇性可用 → 加延时（1-1.5秒间隔）
- 空间API全封 → 用搜索API代替
- 必要时用 bilibili-api-python 库（自带重试）
