---
name: bilibili-content-mining
description: Extract structured information from B站的视频（探店、测评等）without watching the videos. Search API → video detail → comments → danmaku → sub-replies → geocoding pipeline.
---

# B站视频内容挖掘

当用户需要从B站视频中提取**店名、地址、价格、评价**等结构化信息，但无法直接观看视频时，使用此工作流。

## 触发条件

- "找出XX博主关于XX的内容"
- "从B站视频中提取店铺信息"
- "整理XX的视频推荐清单"
- 任何需要从B站视频中获取结构化数据但无法播放视频的场景

## 工作流（按顺序执行）

### 1. 搜索视频

优先使用 `search/all/v2`（比 `search/type` 更不容易触发风控）：

```
https://api.bilibili.com/x/web-interface/search/all/v2?keyword=URL编码关键词
```

如果412，换 `search/type`：
```
https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=URL编码关键词&page=1
```

关键Headers（必须带）：
- `Referer: https://www.bilibili.com/`
- `User-Agent: Chrome 120+`

### 2. 获取视频详情

```
https://api.bilibili.com/x/web-interface/view?bvid=BVID
```

提取：aid、cid、播放量、时长、tags。**描述（desc）通常为空，不要依赖。**

### 3. 评论挖掘（核心！信息密度最高）

**热门评论**：
```
https://api.bilibili.com/x/v2/reply/main?oid=AID&type=1&mode=3&ps=20
```

**子回复（楼中楼）—— 地址和店名的金矿**：
```
https://api.bilibili.com/x/v2/reply/reply?oid=AID&type=1&root=RPID&ps=10
```

**关键技巧**：筛选 `rcount >= 5` 的评论去拉子回复，用关键词匹配（"店"、"地址"、"在哪"、"位置"、"路"、"街"、"号"）。

### 4. 弹幕提取

安装 `bilibili-api-python`：
```bash
pip install bilibili-api-python
```

```python
from bilibili_api import video
v = video.Video(bvid="BVID")
dms = await v.get_danmakus(page_index=0)
```

弹幕关键词：`['元','钱','贵','便宜','好吃','值','坑','良心','鲜','店','地址','码头']`

### 5. 地理编码

用 OSM Nominatim（需要走代理 `127.0.0.1:7897`）：
```
https://nominatim.openstreetmap.org/search?q=关键词+城市&format=json&limit=3&accept-language=zh
```

### 6. 视频下载+转写（深度需求时）

```bash
# 安装依赖
pip install you-get openai-whisper
# Windows需要额外安装ffmpeg

# 下载最低画质
you-get --format=dash-flv360-AV1 -o /tmp "https://www.bilibili.com/video/BVID"

# 转写
whisper 视频文件 --model tiny --language zh --output_format txt
```

## API可用性速查

| 端点 | 无需登录 | 稳定性 | 用途 |
|------|:---:|:---:|------|
| `search/all/v2` | ✅ | ⭐⭐⭐ | 搜索视频 |
| `search/type` | ✅ | ⭐⭐ | 搜索视频（备用） |
| `view` | ✅ | ⭐⭐⭐ | 视频详情 |
| `view/detail` | ✅ | ⭐⭐⭐ | 含tags |
| `reply/main` | ✅ | ⭐⭐⭐ | 热门评论 |
| `reply/reply` | ✅ | ⭐⭐⭐ | 子回复 |
| `space/wbi/arc/search` | ❌ | ⭐ | 需WBI签名 |
| `ai_conclusion` | ❌ | ⭐ | 需登录 |
| `get_danmakus` | ✅ | ⭐⭐⭐ | 需bilibili-api库 |

## 信息提取优先级

评论子回复 > 弹幕 > 热门评论 > 视频标题 > 视频描述（常为空）

关键线索词：
- 地址："路"、"街"、"号"、"小区"、"旁边"、"对面"
- 店名："叫XX"、"XX店"、"就是XX"
- 价格："元"、"块"、"人均"、"花多少"
- 评价："好吃"、"坑"、"贵"、"便宜"、"良心"、"推荐"

## 已知限制

- B站API间歇性412风控，切换端点或稍等重试
- 视频描述几乎总是空的
- 字幕/subtitle通常无数据（短视频UP主不上传）
- AI总结需要登录凭证
- OSM对中国POI覆盖不完整，街道路名可用但具体店铺不能依赖
- whisper需要ffmpeg（Windows需单独安装）
