---
name: bilibili-content-extraction
description: Extract structured information from B站 (Bilibili) videos when you can't watch them — search, comments, AI summaries, subtitles. Covers API quirks, rate-limiting workarounds, and fallback strategies.
---

# B站内容提取 (Bilibili Content Extraction)

When you need to extract structured information (store names, dishes, prices, reviews) from B站 videos
but can't watch them directly. Use B站 APIs to gather metadata, comments, AI summaries, and subtitles
as proxy data sources.

## Trigger conditions

- User asks you to find information from B站 videos / UP主
- You need to extract店名, 地址, 菜名, 价格, 评价 from video content
- Any task involving Chinese video platform research where playback isn't feasible

## Core workflow

### Step 1: Find the UP主's UID

Use the search API to find the user first:

```
api.bilibili.com/x/web-interface/search/type?search_type=bili_user&keyword=<URL-encoded name>
```

From the response, extract `data.result[0].mid` — this is the UID needed for space queries.

Known UIDs (save time):
- JASON刘雨鑫 (XFUN吃货俱乐部主持人): 403082144

### Step 2: Search for videos by topic

Two approaches — prefer the first:

**A) Search API (more reliable, less rate-limited):**
```
api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=<UP主名+地点>&page=1
```
Returns `data.result[]` with title, bvid, author, tag, play count, description.

**B) Space API (often triggers 412, use as last resort):**
```
api.bilibili.com/x/space/wbi/arc/search?mid=<UID>&keyword=<topic>&order=pubdate&ps=30&pn=1
```
This endpoint frequently returns "风控校验失败" — fall back to search API when it does.

### Step 3: Get video details

```
api.bilibili.com/x/web-interface/view/detail?bvid=<BVID>
```
Returns `data.View` with full metadata including aid (needed for comments).

### Step 4: Extract content from comments (MOST IMPORTANT)

Video descriptions are almost always **empty** on B站 for short-form 探店 videos. The comment section is the richest data source:

```
api.bilibili.com/x/v2/reply/main?oid=<aid>&type=1&mode=3&ps=20
```

- `mode=3`: hot排序 (recommended)
- Filter replies with `like >= 20` or `rcount >= 3` for signal
- Strip HTML tags with `re.sub(r'<[^>]+>', '', msg)`
- Comments often contain: store names, prices, local opinions, corrections to the UP主's take

#### Sub-reply mining (楼中楼) — CRITICAL for addresses

When a top-level comment asks "在哪?" or "店名叫什么?", the answer is often in a **sub-reply**:

```
api.bilibili.com/x/v2/reply/reply?oid=<aid>&type=1&root=<rpid>&ps=10
```

- Target top-level comments with `rcount >= 5` (many replies = likely a Q&A thread)
- Filter sub-replies for location/address keywords: `店, 地址, 位置, 在哪, 路, 街, 号, 码头, 市场, 小区`
- A single sub-reply mentioning "照片顶上有个XX小区,结合店名搜一下吧" can unlock the entire location puzzle
- Sub-replies are also the best source for price confirmations and local perspective corrections

### Step 5: Danmaku (弹幕) analysis

Danmaku provides real-time viewer reactions pinned to video timestamps — useful for price/quality signals:

**Via bilibili_api (preferred):**
```python
from bilibili_api import video
v = video.Video(bvid="BV...")
dms = await v.get_danmakus(page_index=0)
for dm in dms:
    print(f"{dm.text}")  # dm.text is the danmaku content
```

**Via you-get (XML format):**
```bash
you-get --format=dash-flv360-AV1 -o /tmp "https://www.bilibili.com/video/BV..."
# This also downloads the .cmt.xml danmaku file
```
The XML has timestamps: `d p="SECONDS,1,25,..."` — the first number is the second in the video.

Keywords to filter danmaku for: `贵, 便宜, 钱, 元, 块, 坑, 良心, 好吃, 在哪, 码头, 地址`

### Step 6: Location geocoding via OSM Nominatim

For addresses extracted from comments, use OpenStreetMap Nominatim (free, no API key):

```
https://nominatim.openstreetmap.org/search?q=<URL-encoded Chinese query>&format=json&accept-language=zh
```

- **Must use proxy** (e.g., Clash Verge port 7897) — OSM times out on direct connections from China
- Chinese POI coverage is limited but landmarks work: 渔人码头, 马栏广场, 长山岛
- Combine with `urllib.request.ProxyHandler` in Python
- Fall back to constructing district-level addresses from confirmed neighborhood names

### Step 7: Validate location tags with related videos

B站 video tags can be misleading (e.g., a video tagged "大连" might actually be about 延吉). To verify:

1. Check `api.bilibili.com/x/web-interface/view/detail?bvid=<BVID>` → `data.Related[]`
2. If all related videos are about a different city, the tag is likely wrong
3. Cross-reference with comment content: if comments keep mentioning a different city, exclude the video

### Step 8: Video download + transcription (last resort)

When all proxy data sources are exhausted, download the video and transcribe:

```bash
# Install tools
pip install you-get openai-whisper
# ffmpeg is required by whisper — install separately

# Download video (lowest quality)
you-get --format=dash-flv360-AV1 -o /tmp "https://www.bilibili.com/video/BV..."

# Transcribe with whisper tiny model (~72MB, works on CPU)
whisper /tmp/video.mp4 --model tiny --language zh --output_format txt
```

- `you-get` cookie warning for HD formats is non-blocking — 360p works without login
- whisper `tiny` model is fast enough for CPU and sufficient for Chinese speech recognition
- Without ffmpeg, whisper fails with `FileNotFoundError` — install it first

### Step 9: AI summaries and subtitles (low success rate, needs auth)
```
api.bilibili.com/x/web-interface/view/conclusion?bvid=<BVID>
api.bilibili.com/x/player/v2?bvid=<BVID>&cid=<cid>
```
These often return empty or require login. The `bilibili_api` methods `get_subtitle()` and `get_ai_conclusion()` also need credentials. Don't rely on them.

## Pitfalls

| Pitfall | Solution |
|---------|----------|
| **412 Precondition Failed** | B站 rate limits aggressively. Some endpoints (space/wbi) are stricter than others. Rotate between search/type and search/all/v2. Add 1-1.5s delays between requests. If you hit 412, wait 5s and retry with a different endpoint. |
| **Search API returns irrelevant results** | The `keyword` parameter on search/type does a broad match. Always filter results by `author` field to ensure they're from the target UP主. |
| **Video descriptions are empty** | This is NORMAL on B站 — most UP主s don't write descriptions. Fall back to comments immediately; don't waste time retrying desc endpoints. |
| **Subtitles/AI summaries unavailable** | Most short-form videos (2-5min) have no subtitles. The AI summary endpoint only works for videos where B站 has generated one AND you have login credentials (`Credential` with sessdata). Assume both will fail and start with comments. |
| **Chinese search engines return SPA pages** | Baidu, Sogou, 360 all return JS-rendered SPAs that curl can't parse. Don't try to scrape them. Use B站's own APIs instead, or search via subagent with browser tools. |
| **curl vs Python urllib** | Python's `urllib.request` with proper headers is more reliable for B站 APIs than curl. Always include: `User-Agent` (Chrome 120+), `Referer: https://www.bilibili.com/`, `Origin: https://www.bilibili.com`, `Accept-Language: zh-CN,zh;q=0.9`. |
| **Location tags can be misleading** | B站 video tags are user-added and sometimes wrong (e.g., a 延吉 video tagged 大连). Validate by checking `view/detail` → `Related[]` videos and comment content. If related videos and comments are about a different city, exclude the video. |
| **whisper needs ffmpeg** | `openai-whisper` requires ffmpeg to extract audio from video files. On Windows: `winget install ffmpeg` or download static build. Without ffmpeg, whisper fails with `FileNotFoundError` on subprocess. |
| **OSM Nominatim times out without proxy** | OpenStreetMap's geocoding API is blocked from mainland China. Always route through proxy (Clash Verge 7897) using `urllib.request.ProxyHandler`. |
| **B站合集 (season) API triggers 风控** | The `space/wbi/season/list` endpoint is aggressively rate-limited. Use `view/detail` instead — it includes `ugc_season` info with the合集 ID and title. |
| **Sub-replies hold the answers** | Top-level comments often ask "在哪?" but the answer is in sub-replies. Always fetch sub-replies (`/reply/reply`) for comments with `rcount >= 5`. A single sub-reply like "照片顶上有个XX小区" can unlock the location. |

## Request headers template

```python
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": "https://www.bilibili.com/",
    "Origin": "https://www.bilibili.com",
}
```

## Verification

After collecting data, cross-reference:
1. Comments from multiple videos mentioning the same store/location
2. High-like comments (>100 likes) from self-identified locals — these carry more weight
3. Tag any claim that comes ONLY from comments (not video content) as "评论区来源, 待确认"

## See also

- `references/bilibili-api-endpoints.md` — full endpoint reference with response shapes, rate limit guidance, and JSON schemas for every API used in the workflow.
- `references/dalian-jason-liuyuxin.md` — pre-extracted data for JASON刘雨鑫's Dalian food reviews (4 confirmed restaurants with addresses, prices, and verdicts from 2026-06).
