---
name: investment-analysis
description: "Build multi-dimensional investment analysis frameworks for commodities, equities, or any asset class. Uses weighted scoring across macro, technical, sentiment, and valuation dimensions with regime-switching logic."
version: 1.1.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [investment, analysis, framework, scoring, gold, commodity]
---

# Investment Analysis Framework Design

## Overview

Systematic methodology for building quantitative investment analysis frameworks. Produces a weighted multi-dimensional scoring engine with regime-switching logic, calibrated to the user's specific asset, investment horizon, and risk profile.

**Core principle:** Present the FULL framework for user evaluation before asking "what next." Never jump to next-step options before the user has seen and evaluated the work product.

## When to Use

Use this skill when the user asks for:
- Investment analysis framework for any asset (gold, stocks, crypto, etc.)
- Trading signal system / buy-sell recommendations
- Quantitative scoring model for investment decisions
- "Act as a financial analyst team"

## The Process

### Step 1 — Clarify Scope

Before any research, ask three questions:

1. **What asset?** (specific product — e.g., 积存金 vs 黄金ETF vs 期货 → different cost structures, different strategies)
2. **What time horizon?** (short-term swing / medium-term trend / long-term accumulation / mixed)
3. **Risk/liquidity constraints?** (urgent liquidity needs? maximum acceptable drawdown?)

### Step 2 — Parallel Research (use delegate_task)

Fan out two research subagents in parallel:

**Research Agent A — Analysis Frameworks:**
Research the most effective quantitative frameworks for this asset. Cover:
- Macro indicators (the foundational drivers)
- Technical indicators (asset-specific calibrations — don't use generic stock parameters)
- Sentiment & positioning indicators
- Valuation models (fair value, relative value, composite scoring)
- Signal synthesis approaches (weighted scoring, regime-switching, ensemble)
- Practical execution calendar (weekly/monthly/quarterly checklist)

**Research Agent B — Data Sources:**
Research accessible (preferably free) data sources for all indicators identified by Agent A. Cover:
- APIs and their endpoints, rate limits, fields
- Python libraries for data retrieval
- China-accessible alternatives where relevant

### Step 3 — Design the Framework

Synthesize research into a structured framework with:

1. **Multi-dimensional scoring engine** — typically 3-5 dimensions, each with:
   - Weight (must sum to 100%)
   - Specific indicators with thresholds
   - Scoring logic (-2 to +2 per indicator)

2. **Regime detection logic** — classify the current market environment and adjust weights/strategy

3. **Signal → action mapping** — clear score-to-action thresholds

4. **Execution calendar** — weekly/monthly/quarterly review cadence

### Step 4 — Present the FULL Framework

**CRITICAL — Don't skip this step or truncate it.**

Present each module clearly with:
- The indicators, their data sources, and their logic
- The specific thresholds for each signal
- The scoring formula and action mapping
- The regime-switching rules

Only AFTER presenting the full framework, ask the user to evaluate:
- Is the logic sound?
- Are the weights appropriate?
- Are the thresholds reasonable?
- What's missing?

### Step 5 — Iterate

Incorporate user feedback on weights, thresholds, missing indicators, or methodology changes. Re-present as needed.

### Step 6 — Advanced Analytics (when basic scoring is stable)

Once the basic multi-dimensional scoring engine is built and running, layer on advanced analytical capabilities:

1. **Signal Layering**: Classify every sub-signal by half-life (L1=days, L2=months, L3=years). Short-term noise should not override structural signals. See `gold-investment-analysis` for the full L1/L2/L3 taxonomy.

2. **Confidence Scoring**: Build a meta-scorer (0-100) that evaluates how reliable the current composite score is, based on signal consensus, layer alignment, signal strength, and data quality. Use confidence to constrain action recommendations — low confidence → downgrade aggressiveness.

3. **Synthesis Generation**: Generate a narrative analytical paragraph (not a bullet list) that explains the WHY behind the score: market positioning → core drivers → risks → directional judgment → actionable advice. The synthesis, not the score, is what investors actually read.

4. **Claude Code as Design Consultant**: For significant architectural changes (framework design, model review, analytical logic), use Claude Code as a design consultant. It reviews the current design and proposes improvements. Hermes Agent handles all code implementation.

### Step 7 — Implement (only after approval)

Once the user approves the framework design, offer to:
- Build automated scoring scripts (Python)
- Set up cron jobs for periodic reports
- Run a current-market analysis

## Pitfalls

**Jumping to "what next" before presenting the framework.** The user hired you to design the framework; they need to evaluate it before discussing execution. Present → evaluate → then discuss next steps.

**Using generic stock parameters for commodities.** Gold trends differently — longer cycles, more persistent trends. MACD on weekly/monthly matters more than daily. RSI thresholds shift. Calibrate per asset.

**Skipping the asset-specific product question.** 积存金 (accumulation plan with high fees) needs different strategy than gold futures or ETFs. The product structure constrains the strategy.

**Not asking about time horizon before designing.** A daily swing trader needs completely different indicators and thresholds than a monthly accumulator.

## Framework Architecture Template

```
┌─────────────────────────────────────────────────┐
│          Multi-Dimension Scoring Engine          │
│                                                  │
│  Dimension 1 (W%) + Dimension 2 (W%) + ...       │
│                      ↓                           │
│          Composite Score [-2, +2]                │
│                      ↓                           │
│     Regime Detector (adjusts weights)            │
│                      ↓                           │
│  ┌─ Advanced Analytics Layer ──────────────┐    │
│  │  Signal Layering (L1/L2/L3)              │    │
│  │  Confidence Scoring (0-100)              │    │
│  │  Synthesis Generation (narrative)        │    │
│  └──────────────────────────────────────────┘    │
│                      ↓                           │
│    Action + Allocation + Price Guidance          │
└─────────────────────────────────────────────────┘
```

Default dimension weights (adjust per asset and horizon):
- **Macro/Structural**: 25-35% (foundational drivers)
- **Technical/Trend**: 15-20% (price action confirmation)
- **Sentiment/Positioning**: 10-15% (crowding/contrarian signals)
- **Valuation**: 15-20% (are you overpaying?)
- **Specialized dimensions**: 10-25% (asset-specific: central bank for gold, supply-demand for oil, etc.)

## Reference Files

- `references/gold-framework.md` — Complete gold investment framework for 积存金
- See also: `gold-investment-analysis` skill for the full v3.0 implementation with signal layering, confidence scoring, and synthesis engine
