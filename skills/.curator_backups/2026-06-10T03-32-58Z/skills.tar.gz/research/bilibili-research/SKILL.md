---
name: bilibili-research
description: Extract content from B站 (Bilibili) — search videos, find UP主 info, mine comments for details, geolocate venues. Use when researching Chinese content on B站, especially when web scraping fails due to SPA/JS rendering.
---

# B站 Research Methodology

## When to use

Any task requiring information extraction from B站 (Bilibili) videos: restaurant reviews, product mentions, tutorial content, news analysis, etc. Especially useful when the B站 web UI is JS-rendered and direct scraping fails.

## Core workflow

### Phase 1: Find the UP主

1. **Search UP主 by name** (this API is the most reliable entry point):
   ```
   GET https://api.bilibili.com/x/web-interface/search/type?search_type=bili_user&keyword={URL_ENCODED_NAME}
   ```
   Returns: `mid`, `uname`, `fans`, `videos`, `usign`, recent 3 videos.

2. **If user search returns 412**, try URL-encoding the Chinese characters and adding a `Referer: https://www.bilibili.com/` header. Python's `urllib` with standard browser UA usually works where curl fails.

### Phase 2: Search for target content

3. **Search videos by keyword + UP主 name**:
   ```
   GET https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword={KEYWORD}&page={N}
   ```
   This API is more stable than the space/wbi API. Filter results by `author` field to match the target UP主.

4. **Alternative: search/all/v2** for broader results:
   ```
   GET https://api.bilibili.com/x/web-interface/search/all/v2?keyword={KEYWORD}
   ```
   Returns results grouped by type (video, article, user, etc.). Use for discovery.

### Phase 3: Extract video details

5. **Get video metadata**:
   ```
   GET https://api.bilibili.com/x/web-interface/view?bvid={BVID}
   ```
   Returns: title, desc, duration, pubdate, stat (views/danmaku/replies/favorites), owner, aid, cid.

6. **Get video detail (includes ugc_season/series info)**:
   ```
   GET https://api.bilibili.com/x/web-interface/view/detail?bvid={BVID}
   ```
   The `ugc_season` field shows which series/playlist the video belongs to — useful for finding related content.

### Phase 4: Mine comments (MOST VALUABLE)

7. **Get top comments** (hot-sorted):
   ```
   GET https://api.bilibili.com/x/v2/reply/main?oid={AID}&type=1&mode=3&ps=20
   ```
   `oid` = `aid` from the view API. `mode=3` = hot-sort. `ps` = page size.

8. **Get sub-replies (楼中楼)** — this is where the gold is:
   ```
   GET https://api.bilibili.com/x/v2/reply/reply?oid={AID}&type=1&root={RPID}&ps=10
   ```
   `root` = `rpid` from a top-level reply. Only fetch for replies with `rcount >= 5`.
   Sub-replies often contain store names, addresses, and local insider info that the video description lacks.

9. **Filter sub-replies by keywords**: Search for 店, 地址, 位置, 在哪, 路, 街, 号, 市场, etc. to find location-specific details.

### Phase 5: Geolocate

10. **Use OpenStreetMap Nominatim** (free, no key needed):
    ```
    GET https://nominatim.openstreetmap.org/search?q={QUERY}&format=json&limit=3&accept-language=zh
    ```
    Works for major landmarks (渔人码头, 马栏广场, 长山岛). Requires proxy in mainland China.

11. **For smaller venues**, search Baidu Maps or Amap directly — these require browser JS but the user can do it manually with clues extracted from comments.

## API quirks & pitfalls

- **412 Precondition Failed**: B站 anti-bot. Solutions: (a) use `bili_user` or `video` search_type instead of `article`/`space`; (b) add `Referer: https://www.bilibili.com/`; (c) use Python `urllib` with standard browser headers rather than curl in terminal.
- **Space/wbi API (风控校验失败)**: `/x/space/wbi/arc/search` frequently rate-limits. Prefer `/x/web-interface/search/type` instead.
- **Subtitle/AI summary**: Almost never available for short-form videos. Don't rely on these.
- **Video descriptions**: Often empty. The UP主 puts key info in the video itself, not metadata.
- **No location geo-tags**: B站 videos don't carry GPS/location metadata. All location info must come from comments or video frames.

## Tooling notes

- **Python is better than curl** for B站 API calls. The `urllib` module with `ssl._create_unverified_context()` works more reliably than curl, especially for maintaining consistent headers across multiple calls.
- **Rate limiting**: Add 1-1.5s `time.sleep()` between API calls to avoid 412 cascades.
- **Proxy**: OSM/Nominatim requires proxy in China (`http://127.0.0.1:7897` for Clash Verge).
- **B站 search API doesn't need authentication** for basic read operations — no cookie/login required.

## Output format

When compiling results for the user, clearly distinguish:
- ⭐ **Confirmed** (from comments/sub-replies, verifiable)
- 🔍 **Needs video confirmation** (visible in video frame, can't extract via API)

Always provide direct B站 links (`https://www.bilibili.com/video/{BVID}`) so the user can verify.
