# Cron News Search — Google News RSS via curl

## Why not delegate_task web_search?

`delegate_task` with `toolsets=["web"]` for the 4 news searches fails ~66% of the time with
"Authentication Fails (governor)" on this host. The curl + proxy approach works reliably.

## Prerequisites

- Clash proxy running on `127.0.0.1:7897`
- `curl` available in git-bash/MSYS
- `grep` with `-oP` (PCRE) support in git-bash

## Search Patterns

Use `execute_code` to run multiple searches in parallel (each via `terminal()`). Stick to the
Google News RSS endpoint — it returns clean XML with titles and descriptions, no JavaScript.

### Base template

```python
from hermes_tools import terminal

proxy = "http://127.0.0.1:7897"
ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

# Fetch titles
result = terminal(
    f'curl -s -x {proxy} '
    f'"https://news.google.com/rss/search?q=QUERY_HERE&hl=en-US&gl=US&ceid=US:en" '
    f'-H "User-Agent: {ua}" --max-time 15 2>&1 | '
    f'grep -oP \'<title>[^<]+</title>\' | head -15',
    timeout=20
)

# Fetch descriptions (for more context)
result = terminal(
    f'curl -s -x {proxy} '
    f'"https://news.google.com/rss/search?q=QUERY_HERE&hl=en-US&gl=US&ceid=US:en" '
    f'-H "User-Agent: {ua}" --max-time 15 2>&1 | '
    f'grep -oP \'<description>[^<]+</description>\' | sed "s/<[^>]*>//g" | head -10',
    timeout=20
)
```

### Required searches for weekly report

1. **Gold price + macro context**: `gold+price+June+2026`
2. **Fed / monetary policy**: `Federal+Reserve+rate+June+2026`
3. **Geopolitical**: `Israel+Iran+Middle+East+conflict+June+2026`
4. **China gold demand**: `China+gold+demand+Shanghai+June+2026`

Also worth checking specific events if headlines hint at them:
- Jobs data: `US+jobs+report+May+2026+nonfarm+payrolls`
- Fed Beige Book: `Fed+Beige+Book+June+2026`

## Extracting article content

When headline + description aren't enough, try direct article fetch:

```bash
curl -s -x http://127.0.0.1:7897 \
  "ARTICLE_URL" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  --max-time 15 -L 2>&1 | \
  sed -n "s/.*<p[^>]*>\(.*\)<\/p>.*/\1/p" | sed "s/<[^>]*>//g" | head -20
```

Note: `python3` is NOT available in git-bash on this host. Use `sed` / `grep` for text
extraction, not `python3 -c`. The `python` command is available but points to the Windows
Python, which may not be on PATH inside execute_code subprocesses.

## Pitfalls

- **Google News RSS returns HTML entities** — `&amp;`, `&lt;`, `&gt;` in titles/descriptions.
  These are cosmetic and don't affect news extraction. Don't bother decoding them.
- **Paywalled articles** (Fortune, WSJ, Bloomberg) return empty or "Content is currently unavailable."
  Skip them — use the RSS headline + description for these sources.
- **Google News URL encoding**: Use `+` for spaces, NOT `%20`. The RSS endpoint handles `+` correctly.
- **Rate limit**: Keep curl calls spaced by at least 2 seconds. Running 4+ in parallel within
  `execute_code` is fine — the terminal calls are serialized internally.
- **News-data contradiction**: Search results can include stale or fabricated claims (e.g., "中国央行增持32万盎司" when akshare shows a MoM decrease). After extracting news, cross-check any directional or quantitative claims against the `main.py` signals BEFORE writing the 本周要闻 section. If news says "增持" but pboc_reserves is negative → the news is wrong, use the quantitative data. If news says "美元走弱" but dxy_1m_pct > 0 → the news is wrong. See data-validation.md Gate 5e for the full contradiction test table.
