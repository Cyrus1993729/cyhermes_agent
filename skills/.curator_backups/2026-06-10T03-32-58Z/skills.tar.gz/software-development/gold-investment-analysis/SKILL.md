---
name: gold-investment-analysis
description: Build and run gold investment scoring systems (积存金) — seven-factor scoring, weekly reports, data freshness decay, regime detection, signal layering, confidence scoring, synthesis generation, and cron-automated reporting with news integration.
version: 3.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [gold, investment, scoring, china, data-fetching, yfinance, akshare, fredapi, synthesis, weekly, geopolitical]
---

# Gold Investment Analysis System v3.1

Build and operate automated gold investment analysis for 积存金 (Chinese gold accumulation plans). Covers the full pipeline: data fetching → seven-factor scoring → regime detection → signal layering → confidence scoring → synthesis generation → actionable recommendations.

## When to Use

When a user asks for:
- Gold price analysis or investment recommendations
- Automated trading signal systems for gold
- 积存金 strategy design
- Multi-factor scoring models combining macro/technical/sentiment/valuation/central-bank/china-domestic/geopolitical dimensions
- Weekly analytical report generation with news + quantitative analysis
- Cron-automated recurring investment reports

## User Preferences

- **Output in Chinese** — all reports, signals, and explanations must be in Chinese
- **0-100 score scale only** — NOT `[-2, +2]`. Display as `47.9/100`, not `-0.08 [-2,+2]`. Internal computation still uses [-2,+2] but user-facing output is 0-100 only.
- **Signals need analysis, not just labels** — each signal must include specific data values and causal reasoning, not just a name + score
- **Comprehensive synthesis over signal listing** — the final output must include analytical narrative (five-paragraph synthesis), not just a list of bullish/bearish signals. Signals are input, synthesis is reasoning, recommendation is output.
- **Weekly reports, NOT daily** — monthly-frequency data (M2, PBOC reserves, TIPS trend) pollutes daily scores. Weekly with weight decay is the correct frequency. Reports go out Monday 8:00 AM via cron.
- **Confidence must be honest** — low confidence (40-59) when signals are conflicted is correct behavior, not a bug. Do not artificially boost confidence.
- **Concise in chat** — keep WeChat messages compact, use markdown for readability

## Architecture: Seven-Dimension Scoring with Weekly Cadence

```
┌──────────────────────────────────────────────────────┐
│           Gold Scoring Engine v3.1                    │
│                                                      │
│  Macro(20%) + Technical(15%) + Sentiment(10%)        │
│  + Valuation(15%) + CB(20%) + ChinaDomestic(10%)     │
│  + Geopolitical(10%)                                 │
│                    ↓                                 │
│           Composite [-2, +2] → [0-100]               │
│                    ↓                                 │
│    Signal Layering (L1/L2/L3) + Confidence           │
│                    ↓                                 │
│    Data Freshness Decay (monthly modules)            │
│                    ↓                                 │
│    Five-Paragraph Synthesis + News Integration       │
└──────────────────────────────────────────────────────┘
```

### Seven Dimensions

| Dimension | Weight | Key Indicators |
|-----------|--------|----------------|
| Macro Environment | 20% | 10Y TIPS real yield, DXY, Fed policy (2Y-10Y spread), fiscal/GPR |
| Technical Trend | 15% | 50-week MA, MACD weekly, RSI weekly, ADX |
| Sentiment & Positioning | 10% | COT report, GLD ETF flows, gold/silver ratio |
| Valuation | 15% | Fair value residual (TIPS+DXY regression), gold/M2, gold/SPX, gold/oil |
| Central Bank Behavior | 20% | PBOC reserve changes (akshare), gold-DXY decoupling proxy, price resilience |
| China Domestic Demand | 10% | Shanghai premium vs London, RMB FX impact, domestic gold ETF flow |
| **Geopolitical Risk** | **10%** | Oil-gold resonance (DXY-orthogonalized), precious metal divergence (Au-Ag spread), GVZ excess premium |

### Signal Layering (L1/L2/L3)

Every sub-signal is classified by half-life:

| Layer | Chinese Label | Half-Life | Examples |
|-------|--------------|-----------|----------|
| **L1** | 短期扰动 | 1-10 days | MACD, RSI, COT positioning, ETF short-term flows, Shanghai premium, oil-gold resonance, GVZ premium |
| **L2** | 中期驱动 | 1-6 months | Real yield trend, DXY direction, MA position, fair value residual, GSR, PM divergence |
| **L3** | 结构性锚 | 1+ years | PBOC reserve trend, fiscal/GPR, gold resilience vs equities |

**Layer conflict handling**: When L1 contradicts L2/L3, L1 is treated as noise. L3 direction changes require 3 consecutive confirmations.

### Confidence Scoring (Four Dimensions, 0-100)

| Dimension | Max | Method |
|-----------|-----|--------|
| A: Signal Consensus | 25 | % of strong signals pointing same direction |
| B: Layer Alignment | 25 | L1/L2/L3 direction consistency |
| C: Signal Strength | 25 | Average absolute signal magnitude (proxy for decisiveness) |
| D: Data Quality | 25 | Completeness ratio across all components |

**Key insight**: Low confidence when signals are conflicted is **correct behavior, not a bug**. The confidence score is a truthfulness mechanism — it tells the investor when the market itself is unclear.

### Data Freshness & Weight Decay

Monthly-frequency data (M2, PBOC reserves, TIPS trend) decays in weight over time:

| Days Since Update | Weight Factor |
|-------------------|---------------|
| 0-7 days | 100% |
| 8-14 days | 80% |
| 15-30 days | 60% |
| 30+ days | 40% |

Affected modules: **macro** and **central_bank**. Other modules use weekly/daily data — no decay.

The weekly report displays a freshness panel:
```
【数据新鲜度】
  宏观环境: 上次更新 2026-05-25（9天前）→ 权重衰减至 80%
  央行行为: 上次更新 2026-05-08（26天前）→ 权重衰减至 60%
```

### Weekly Report Flow (Monday 8:00 AM Cron)

```
Step 1: News Recap — Google News RSS via curl (do NOT use delegate_task web_search)
  Use execute_code + terminal with proxy to fetch Google News RSS feeds.
  See references/cron-news-search.md for exact curl patterns.
  ├─ Gold price + macro: "gold price June 2026" + "Federal Reserve rate June 2026"
  ├─ Geopolitical: "Israel Iran Middle East conflict June 2026"
  └─ China demand: "China gold demand Shanghai June 2026"
  
  delegate_task with web toolset fails ~66% of the time ("Authentication Fails (governor)").
  The curl + proxy approach is reliably available from cron.

Step 2: Quantitative Analysis (python main.py with proxy)
  └─ HTTP_PROXY=http://127.0.0.1:7897 HTTPS_PROXY=http://127.0.0.1:7897 python main.py

Step 2.5: Data Validation (MANDATORY — see references/data-validation.md)
  ├─ 3.1 Verify COMEX gold price against https://api.gold-api.com/price/XAU (≤2% deviation)
  ├─ 3.2 Verify CNY conversion: COMEX/31.1035 × USDCNH (fetch from https://api.exchangerate-api.com/v4/latest/USD)
  ├─ 3.3 Check Shanghai gold freshness — if SGE date > 2 days stale, replace with conversion
  └─ 3.4 If errors found: fix code/data, re-run python main.py, re-validate

Step 3: Integrated Report
  ├─ 本周要闻 (3-5 events, dated, factual only — from Step 1 headlines)
  ├─ 量化分析 (full main.py output, validated)
  └─ 综合研判 (cross-reference news + quantitative signals)
```

## Report Frequency Design Principle

**The enemy of accuracy is not frequency, but fake synchronization.** 

Old daily reports polluted 40% of the composite score with month-old data pretending to be "today's analysis." The correct approach:
- Weekly report (Monday) as primary output
- COT captures the only truly weekly data
- Monthly dimensions explicitly labeled with age and decay-weighted
- No daily reports — they create false certainty

## Data Source Patterns

### yfinance: ALWAYS use Ticker API with Session

**Never use `yf.download()`** — it triggers aggressive rate limiting (especially from China). Use `yf.Ticker(ticker, session=requests_session).history()` instead.

```python
import requests
import yfinance as yf

session = requests.Session()
session.headers.update({
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
})
session.get('https://finance.yahoo.com', timeout=5)  # pre-warm

tk = yf.Ticker("GC=F", session=session)
df = tk.history(period="2y", interval="1d", auto_adjust=False)
```

Retry with exponential backoff (4 retries, 5s base). 2s inter-call cooldown. Cache as CSV with 1-day TTL, force DatetimeIndex and strip timezone on load.

### akshare: Shanghai Gold Column Mapping

`ak.spot_golden_benchmark_sge()` returns Chinese column names. Rename to English:
```python
col_map = {'交易时间': 'Date', '晚盘价': 'Evening', '早盘价': 'Close'}
df = df.rename(columns={k: v for k, v in col_map.items() if k in df.columns})
df['Close'] = pd.to_numeric(df['Close'], errors='coerce')
```

For PBOC gold reserves, try multiple akshare functions in order: `macro_china_gold_reserve()`, `macro_china_fx_gold()`, `macro_china_foreign_exchange_gold()`, `gold_reserve()`, `gold_holding()`.

### FRED API: Setup

1. Register at https://fred.stlouisfed.org/docs/api/api_key.html
2. Set `FRED_API_KEY` env var (never hardcode)
3. Key series: `DFII10` (10Y TIPS), `M2SL` (M2), `T10Y2Y` (2Y-10Y spread)
4. TIPS yield from FRED is in percentage form (e.g., 2.07 for 2.07%) — do NOT multiply by 100 for display

### China Domestic: Sina API for ETF Data

For Chinese gold ETF volume data, Sina Finance API is more reliable than akshare (bypasses Clash TUN interception):
```python
url = "https://stock.finance.sina.com.cn/fundInfo/api/openapi.php/CaihuiFundInfoService.getNav"
# Fetch 518880 (华安黄金ETF) and 159937 (博时黄金ETF)
```

### Dual-Network Proxy Pattern

yfinance/FRED → needs proxy. akshare/eastmoney.com → needs DIRECT. Use Clash rule mode: `eastmoney.com` → DIRECT, everything else → proxy.

### Geopolitical Module: Three Market-Price Proxies

All signals DXY-orthogonalized to avoid double-counting with macro module:

1. **Oil-Gold Resonance (40%)**: DXY-orthogonalized oil+gold co-move, amplified when equities decline. Captures Middle East conflict fingerprint.
2. **Precious Metal Divergence (35%)**: Gold vs Silver 20-day return spread Z-score. Naturally DXY-orthogonal (both USD-priced). High spread = pure safe-haven demand.
3. **GVZ Premium (25%)**: GVZ excess over SPX-vol-expected level, filtered by gold direction. Rising gold + high GVZ excess = geopolitical tail-risk pricing.

## Project Convention

Reference implementation at `C:\Users\Administrator\gold_analyzer\`:
- `config.py` — weights (7-dim), threshold configs, ticker symbols, weight decay schedule, env-var-driven API keys
- `data_fetcher.py` — unified data fetching with cache, retry, session management, dual-network routing
- `macro.py`, `technical.py`, `sentiment.py`, `valuation.py`, `central_bank.py`, `china_domestic.py`, `geopolitical.py` — per-dimension scorers
- `scorer.py` — composite scoring + regime detection + signal layering + confidence + freshness decay + synthesis
- `main.py` — weekly report entry point, formats Chinese report, saves JSON + archives

Run weekly report with:
```bash
cd C:\Users\Administrator\gold_analyzer
HTTP_PROXY=http://127.0.0.1:7897 HTTPS_PROXY=http://127.0.0.1:7897 python main.py
```
**Always include the proxy env vars.** yfinance will rate-limit without them; the run will time out after 300s.

Cron job for automated weekly delivery:
- Job ID: `54117ed8a949`
- Schedule: `0 8 * * 1` (Monday 8:00 AM CST)
- Delivers to: origin (WeChat DM)
- Workflow: news search → quantitative analysis → integrated report

## Claude Code as Design Consultant

When significant architectural changes are needed (not code, but design), use Claude Code as a consultant:

```bash
export HTTP_PROXY=http://127.0.0.1:7897
export HTTPS_PROXY=http://127.0.0.1:7897
claude --dangerously-skip-permissions -p "设计问题描述（中文）" 
```

Claude Code is used for: framework design, model review, analytical logic critique, report frequency analysis. It is NOT used for writing implementation code — Hermes Agent handles all code changes.

## Pitfalls

1. **yfinance rate limiting**: `yf.download()` fails silently. Always use `Ticker(session=...).history()` with retry.
2. **akshare column names**: Chinese names change between versions. Inspect raw output before mapping.
3. **Cache timezone**: CSV round-trips lose timezone. Force `tz_localize(None)` after loading.
4. **FRED TIPS yield units**: Returns percentage (2.07 = 2.07%), not decimal. Don't multiply by 100 for display.
5. **TIPS trend window**: Use fixed 63-day window, NOT `len/2` split (which varies by data availability).
6. **Decoupling double-counting**: Gold-DXY decoupling is checked in both macro and central_bank modules. Ensure scoring logic avoids double-counting.
7. **Signal dampening**: Use 70/30 EMA weighting for direction changes, not 50/50 mean. After 2+ consecutive periods in same direction, trust the signal.
8. **ETF volume alignment**: Domestic ETF volumes have different date indices — use `pd.concat().sum(axis=1)` for proper alignment.
9. **Fair value price guidance**: Always anchor price suggestions to fair value, even when composite score > 1.0. Never suggest buying above fair value.
10. **No scipy**: Use numpy for all statistical computations.
11. **Daily reports are WRONG**: 40% of model weight (macro + CB) uses monthly data. Daily reports create false certainty. Use weekly only.
12. **Confidence is honesty, not quality**: Low confidence during conflicted signals is correct. Don't boost it.
13. **Python string escaping**: When using patch tool for Python files, avoid backslash-escaped quotes (`\\\"`) — use unescaped quotes in old_string/new_string.
14. **scorer.py format string crash on missing FRED data**: `_explain_signal` for `fed_policy` does `f"{sp:.2f}%"` on the 2Y-10Y spread, but when FRED_API_KEY is unset, `sp` can be a string like `"no_data"` — causes `ValueError: Unknown format code 'f' for object of type 'str'`. Fix with `try: sp_val = float(sp)` / `except (ValueError, TypeError):` fallback. See the `_explain_signal` method around line 374. This bug silently breaks the entire report generation.
15. **auto_adjust=True on futures distorts prices**: `tk.history(auto_adjust=True)` on futures contracts (GC=F, SI=F, CL=F) applies contract-roll adjustment, which shifts historical prices to match the front-month contract — creating systematic price drift vs actual spot/market prices. **Always use `auto_adjust=False` for futures tickers.** The `_yf_download` method in data_fetcher.py must pass `auto_adjust=False`. After the fix, clear all yfinance caches (`gold_price.csv`, `dxy.csv`, `oil.csv`, `silver.csv`, `gld.csv`, `gvz.csv`, `sp500.csv`) before re-running — stale adjusted prices will persist in cache for up to 24 hours.
16. **auto_adjust=False returns Adj Close column → duplicate rename collision**: When `auto_adjust=False`, yfinance returns BOTH `Close` and `Adj Close` columns. The column rename logic in `_yf_download` matches "close" against both, creating duplicate "Close" columns. Then `df['Close']` returns a DataFrame (not Series), causing `float() argument must be a string or a real number, not 'Series'` in `safe_pct_change`. Fix: in the rename loop, match "adj close" / "adj" FIRST and drop those columns before renaming the remaining "Close".

17. **Shanghai gold data can lag 2-4 days behind COMEX**: akshare's SGE data (`spot_golden_benchmark_sge()`) typically lags 1-2 trading days, and can stretch to 4+ days over weekends. When COMEX makes a large move (e.g., Friday non-farm payrolls crash) and SGE data hasn't updated yet, the stale SGE price distorts the Shanghai premium signal. **Always verify**: compare the latest date in Shanghai gold CSV to the latest COMEX date. If SGE is stale, use direct conversion as fallback:
   ```
   Shanghai_estimated = COMEX_USD / 31.1035 × USDCNH
   ```
   Do NOT add an artificial premium (1.4%, 2%, etc.) on top of the synthetic estimate — the premium signal must come from actual market data, not baked into the fallback. The synthetic row should be tagged as estimated so it's replaced when real SGE data arrives. After adding the row, re-run `main.py` so the scoring model recomputes the premium with the corrected base price.

18. **USDCNH must be fetched fresh alongside COMEX for conversion**: When computing the synthetic Shanghai price, always fetch the latest USDCNH (via `CNH=X` from yfinance) at the same time as COMEX gold. Do not use a stale cached rate or a hardcoded value. The conversion formula is `COMEX_USD / 31.1035 × USDCNH` — a 0.1 CNY error in the rate translates to ~¥14/克 error in the price.

19. **PBOC reserves scoring must combine MoM + YoY, not binary recent-vs-prev**: The original `score_pboc_reserves()` in `central_bank.py` used a naive binary: `recent > prev ? +1.0 : -1.0`. A -0.99% MoM dip in a +40% YoY uptrend was scored identically to a genuine trend reversal. The fix uses the `黄金储备-同比` column (available from `ak.macro_china_fx_gold()`) to contextualize the MoM change. **The user explicitly rejected classifying a -0.99% MoM dip in a +40% YoY trend as negative** — such small monthly fluctuations are noise, not signals. Final thresholds:
    - MoM decrease + YoY > 20% + |MoM| < 1.5% → **+0.3** (strong uptrend, monthly noise — STILL POSITIVE)
    - MoM decrease + YoY > 20% + |MoM| < 3.0% → **0.0** (dip in uptrend, neutral)
    - MoM decrease + YoY > 20% + |MoM| >= 3.0% → **-0.3** (notable dip in uptrend)
    - MoM decrease + YoY < -5% → **-1.5** (genuine trend reversal)
    - MoM increase + YoY > 10% → **+1.0** (buying within strong trend)
    - MoM increase + YoY > 0% → **+0.8** (buying, modest trend)
    - Flat MoM + YoY > 10% → **+0.3** (steady accumulation)
    The akshare dataframe has `黄金储备-同比` and `黄金储备-环比` columns — use them.
    
20. **DXY scoring must be trend-adjusted, not purely level-based**: The DXY threshold table gives +2.0 for any reading < 100 (incl. 99.95) and +1.0 for 100-103. But a DXY at 99.95 that has risen 1.7% in the past month is fundamentally different from a DXY crashing from 105 to 97. The fix in `macro.py:score_dxy()`:
    - Compute 1-month DXY change via `safe_pct_change(dxy_df, col, window=21)`
    - If DXY has risen > 2% in a month → dampen level score by -1.0
    - If risen 1-2% → dampen by -0.5
    - If fallen < -2% → amplify by +1.0
    - Replace the old `decoupling_bonus` logic (which checked gold+DXY co-move) with this trend adjustment
    The signal explanation text must reflect the trend: "美元指数 99.95（近1月走强1.7%），虽处低位但趋势走强，对黄金的实际利好被削弱"

21. **COT signal explanation must distinguish net-long neutral from "净空"**: The original `_explain_signal` for COT used `score < 0 ? '偏重' : '偏轻或净空'`. For score=0 (176k net long), this falsely said "或净空" when the position was clearly net long. The fix splits into three cases:
    - score < 0 → "投机持仓偏重，利空后续加仓"
    - score > 0 → "持仓偏轻，有加仓空间，利于后续加仓"  
    - score == 0 → "持仓适中，利于后续加仓"

22. **real_yield signal explanation must handle missing FRED data**: When FRED_API_KEY is unset, `current_yield` is None. The old ternary `score>0 ? '走低利好' : '偏高利空'` falsely said "偏高利空" when there was no data. Fix: `score>0 ? '走低利好' : (score<0 ? '偏高利空' : '数据不可用')`. The fed_policy component has a similar issue (pitfall 14 — string format crash on `no_data`).

- **News from delegated subagents is NOT verified fact**: When the cron job uses delegate_task to search for weekly news, subagents can hallucinate specific numbers (e.g., "增持32万盎司" when akshare shows a decrease). Cross-check all subagent-sourced news against quantitative data. If news says "中国央行增持" but pboc_reserves signal shows a MoM decrease → the news is wrong, use the quantitative data. The 综合研判 section must reconcile news-data contradictions explicitly rather than papering over them.

24. **Price guidance uses china_domestic score, not overall composite**: In `china_domestic.py:compute_price_guidance()`, the `composite` parameter determines the verb (积极加仓/正常定投/等待回调/暂停) and price range. The original `scorer.py:run_analysis()` passed `china_score` (+0.86, almost always bullish) instead of the overall composite (typically 0.0-0.2, neutral). This made the 💰 guidance line ALWAYS say "正常定投" regardless of the actual action recommendation. **Symptom**: "维持观望, 定投50%" paired with "建议在 ¥X-Y/克 正常定投" — the verb contradicts the action. **Fix**: in scorer.py, after computing the overall `composite`, call `self.china.compute_price_guidance(au9999_df, gold_df, usdcnh_df, composite)` with the OVERALL composite and use that result for both the synthesis and the result dict. The result dict's `action_price_guidance` key must also use the corrected value, not `china_bd.get("action_price_guidance")`.