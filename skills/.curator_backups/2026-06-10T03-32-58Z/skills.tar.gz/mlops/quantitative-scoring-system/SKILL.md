---
name: quantitative-scoring-system
description: Build and iterate on multi-dimensional quantitative scoring/investment analysis systems. Covers Claude-as-architect workflow, multi-frequency data handling with freshness decay, signal layering (L1/L2/L3), confidence scoring as honesty mechanism, and report frequency design aligned with data frequency.
---

# Quantitative Scoring System Design

Design and iterate on multi-dimensional quantitative scoring systems (e.g. investment analysis, risk scoring, quality gates). Covers the full lifecycle: architecture design, data pipeline, scoring logic, confidence assessment, and report cadence.

## When to Use

- Building any multi-dimensional scoring model with heterogeneous data sources
- Iterating on an existing scoring system (adding dimensions, adjusting weights)
- Designing report/output frequency for a quantitative system
- Auditing confidence/uncertainty in a model's output

## Core Design Principles

### 1. Claude as Architect, Agent as Implementer

When the task involves system design decisions (module structure, signal logic, weight allocation), delegate design to Claude Code first. The agent then implements the approved design.

**Workflow:**
1. Frame the problem clearly for Claude Code (current state, constraints, goals)
2. Let Claude produce a design document (not code)
3. Review the design with the user
4. Agent implements the approved design

**Why:** Claude Code has deeper reasoning capacity for architectural decisions. Separating design from implementation prevents the agent from making poor architectural choices it then has to undo.

### 2. Multi-Frequency Data → Data Freshness Decay

When a scoring system combines data sources with different update frequencies (daily, weekly, monthly), **do not pretend all dimensions are synchronized**. Use explicit freshness decay:

```
Slow variable weight decay:
  Week 1 after release: 100% weight
  Week 2 after release:  80% weight
  Weeks 3-4 after release: 60% weight
  30+ days after release:  40% weight
```

Fast variables refresh every cycle at full weight. The composite score's integrity improves because stale data is explicitly discounted rather than silently polluting the conclusion.

**Pitfall:** The original sin is "假同步掩盖真异步" (faking synchronization to hide asynchrony). A daily report that gives equal weight to a 30-day-old M2 reading and today's gold price produces **worse** conclusions than ignoring the stale dimension entirely — it manufactures false certainty.

### 3. Signal Layering (L1/L2/L3)

Classify every sub-signal by its half-life, not its source module:

| Layer | Half-life | Examples | Weight treatment |
|-------|-----------|----------|------------------|
| L1 短期扰动 | 1-10 trading days | MACD cross, RSI extremes, ETF flow spikes | x0.3 when conflicting with L2/L3 |
| L2 中期驱动 | 1-6 months | Real yield trend, DXY direction, MA position | Standard weight |
| L3 结构性锚 | 1+ years | Central bank reserves, de-dollarization, fiscal trajectory | Requires 3 consecutive confirmations to flip direction |

When L1 bearish signals conflict with L2/L3 bullish signals, the L1 signals are noise — flag them but don't let them override the medium/long-term framework. When L2 bullish and L2 bearish signals coexist, the market is in genuine equilibrium and confidence should drop.

### 4. Confidence Scoring as Honesty, Not Quality

Confidence scoring should answer: "How reliable is today's conclusion given the signal distribution?" — NOT "How good is our model?"

**Four dimensions of confidence:**

| Dimension | What it measures | When it's low |
|-----------|-----------------|---------------|
| Signal consensus | Bull/bear signal ratio | Market genuinely split ~50/50 |
| Layer alignment | L1/L2/L3 direction agreement | Short vs. long-term forces in conflict |
| Signal strength | Magnitude of dominant signals | No single factor overwhelming |
| Data quality | Missing/stale data ratio | API failures, gaps |

**Critical rule:** Never inflate confidence to make the model look better. Low confidence when signals are genuinely conflicting is **correct behavior**. A system that outputs high confidence during market chaos is lying. 53/100 during a 50/50 split is honest; 75/100 during the same split is fraudulent.

When confidence is low, the correct action is to **reduce position size / defer decisions**, not to manipulate scores.

### 5. Report Frequency Aligned with Data Frequency

Match report cadence to the **fastest data source that drives actionable conclusions**, not to the model's internal update cycle.

**Anti-pattern:** Daily reports when 40% of model weight comes from monthly data. This creates "今日分析" (today's analysis) labels on conclusions that are 30 days stale.

**Correct pattern:** Weekly as primary report, with:
- Fast daily variables aggregated over the week (5-day mean, max single-day move)
- COT/slow variables at their natural refresh
- Data age explicitly labeled per dimension
- No daily reports unless there's a threshold event trigger

**When to add a report frequency:** Only when there exists a data source whose natural frequency matches that cadence AND whose signal meaningfully changes at that cadence. Don't add monthly reports just because monthly data exists — add them when the monthly data can't be adequately handled in the weekly report.

## Pitfalls

- **Signal magnitude ≠ signal reliability**: A signal scoring +2.0 is not necessarily more predictive than one scoring +0.5. Don't use magnitude as a proxy for historical accuracy without validation.
- **Same-module double counting**: When adding a new dimension (e.g. geopolitical), ensure its sub-signals are orthogonal to existing ones. Geopolitical oil-gold resonance must strip out DXY effects (already captured by macro) before scoring.
- **Proxy decay**: A proxy built on correlation (e.g. "DXY weakness = geopolitical risk") will fail when the underlying correlation breaks. Mark all proxy-based signals explicitly.
- **Direction-confirmation mismatch**: When L3 signals (structural) flip direction, require confirmation across multiple cycles before updating. Structural anchors should be sticky.

## Reference Implementation

See `references/gold-scoring-example.md` for the full gold investment scoring system architecture that emerged from applying these principles: 7 dimensions, signal layering, confidence scoring, data freshness decay, geopolitical proxy module.
