# Extracting X/Twitter Auth Cookies from Browser

## Chrome (中文界面)

1. 用 bot 小号登录 x.com
2. 打开开发者工具：
   - 右键页面任意位置 → 「检查」
   - 或者 `Ctrl + Shift + I`
   - 或者右上角 `⋮` → 更多工具 → 开发者工具
3. 顶部标签栏找到 **「应用」**（如果没看到，点 `>>` 展开）
4. 左侧栏：**存储** → **Cookies** → 点击 `https://x.com`
5. 右侧表格找到需要的 cookie，双击 **值** 列，`Ctrl+C` 复制

## Chrome (English)

1. Login to x.com with bot account
2. Open DevTools: F12 or Ctrl+Shift+I or right-click → Inspect
3. **Application** tab (click >> if hidden)
4. Left sidebar: **Storage** → **Cookies** → `https://x.com`
5. Find cookie in table, double-click **Value**, Ctrl+C

## Required Cookies

| Cookie | Purpose | Format |
|--------|---------|--------|
| `auth_token` | Main authentication | 32-char hex string |
| `ct0` | CSRF protection token | 32-char hex string |

## Config File Format

Save to a local file (never send credentials over chat):
```
AUTH_TOKEN="abc123..."
CT0_TOKEN="def456..."
```

## Important Notes

- Token **changes** on re-login or different device
- Token typically lasts **months** without re-login
- The `x-csrf-token` request header **must match** the `ct0` cookie value
- "This request requires a matching csrf cookie and header" = ct0 mismatch
- If token stops working, re-extract both values from the browser session
