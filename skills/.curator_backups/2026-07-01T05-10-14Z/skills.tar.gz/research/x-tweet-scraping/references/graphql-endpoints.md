# X/Twitter GraphQL API Reference

## Bearer Token

Extracted from X's main JS bundle. Find it with:
```bash
curl -sL "https://abs.twimg.com/responsive-web/client-web/main.*.js" | grep -oP 'AAAAA[A-Za-z0-9%\-_]{50,}'
```

Current token (2026-06-24):
```
AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA
```

## Finding Current Query IDs

When API returns 404, the query IDs have rotated. Extract fresh ones from the main JS:

```bash
curl -sL "https://abs.twimg.com/responsive-web/client-web/main.*.js" | \
  grep -oP 'queryId:"[^"]+",operationName:"[^"]+"'
```

Key operations to look for:
- `UserTweets` — user timeline
- `UserTweetsAndReplies` — timeline with replies
- `SearchTimeline` — search results

## Endpoints

All endpoints use: `https://x.com/i/api/graphql/{QUERY_ID}/{OperationName}`

### UserTweets

Get a user's timeline.

**Variables:**
```json
{
  "userId": "1940360837547565056",
  "count": 20,
  "includePromotedContent": false,
  "withVoice": true,
  "withV2Timeline": true
}
```

For pagination, add `"cursor": "..."` from the Bottom cursor in previous response.

**Response structure:**
```
data.user.result.timeline.timeline.instructions[]
  ├─ TimelineAddEntries
  │   ├─ TimelineTimelineItem → tweet
  │   └─ TimelineTimelineCursor → cursor (Top/Bottom)
```

### SearchTimeline

Search tweets with `from:username` + keywords + date filters.

**Variables:**
```json
{
  "rawQuery": "from:aleabitoreddit NBIS since:2025-09-01 until:2025-10-01",
  "count": 20,
  "product": "Latest"
}
```

Search operators:
- `from:username` — tweets from specific user
- `keyword` — exact keyword match
- `since:YYYY-MM-DD` — start date
- `until:YYYY-MM-DD` — end date

**Response structure:**
```
data.search_by_raw_query.search_timeline.timeline.instructions[]
  ├─ TimelineAddEntries
  │   ├─ TimelineTimelineItem → tweet
  │   └─ TimelineTimelineCursor → cursor (Bottom)
```

## Auth Headers (Logged-in)

```python
headers = {
    "Authorization": f"Bearer {BEARER}",
    "Cookie": f"auth_token={AUTH_TOKEN}; ct0={CT0_TOKEN}",
    "x-csrf-token": CT0_TOKEN,
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}
```

The `x-csrf-token` header MUST match the `ct0` cookie value exactly.

## Auth Headers (Guest — Limited)

```python
# Step 1: Get guest token
POST https://api.x.com/1.1/guest/activate.json
  Authorization: Bearer {BEARER}

# Step 2: Use guest token
headers = {
    "Authorization": f"Bearer {BEARER}",
    "x-guest-token": guest_token,
    "User-Agent": "..."
}
```

**Guest limitations:** 97 tweets max, engagement-sorted, no pagination cursor, SearchTimeline returns empty.

## Features Parameter

Minimal required features for most endpoints:
```json
{
  "responsive_web_graphql_exclude_directive_enabled": true,
  "view_counts_everywhere_api_enabled": true,
  "longform_notetweets_consumption_enabled": true,
  "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": true
}
```

## Tweet Object (legacy)

Key fields in `tweet_results.result.legacy`:
- `id_str` — tweet ID
- `created_at` — "Wed Oct 29 05:03:08 +0000 2025"
- `full_text` — tweet content (with t.co URLs)
- `favorite_count`, `retweet_count`, `reply_count`, `quote_count`
- `lang` — language code
- `entities.symbols` — cashtags like ["NBIS", "IREN"]
- `entities.hashtags` — hashtags
- `in_reply_to_status_id_str` — null for original tweets

View count is in `tweet_results.result.views.count`.
