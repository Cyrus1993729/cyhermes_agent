---
name: x-tweet-scraping
description: Scrape X/Twitter user timelines and search tweets via internal GraphQL API with authenticated bot account through proxy. Covers extracting cookies, calling the API, pagination, and search.
category: research
triggers:
  - "抓取 X/Twitter 用户的推文"
  - "搜索某人发的推文"
  - "监控 X 博主动态"
  - "from:username keyword 搜索"
  - "auth_token cookie X API"
  - "nitter 不能用了怎么爬 X"
  - User mentions scraping or monitoring an X/Twitter account
---

# X/Twitter Tweet Scraping

Scrape X user timelines and search tweets using X's **internal GraphQL API** (the one X's own web client uses — free, not the paid developer API).

## Prerequisites

- **Proxy** — required from China. Default: `http://127.0.0.1:7897`
- **Bot X account** — any throwaway account works. Register one at x.com.
- **Two cookies** from the bot account's browser session:
  - `auth_token` — main authentication cookie
  - `ct0` — CSRF token (must match `x-csrf-token` request header)

## Extracting Credentials from Browser

See `references/cookie-extraction.md` for the step-by-step (Chinese Chrome UI path included).

Quick reference:
1. Login to x.com with bot account in Chrome
2. F12 → Application (「应用」) → Storage → Cookies → `https://x.com`
3. Copy `auth_token` value and `ct0` value
4. Save both to a local config file (never send over chat)

## API Details

See `references/graphql-endpoints.md` for the full endpoint reference.

**Bearer Token** (extracted from X's main JS bundle — rotates occasionally):
```
AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA
```

**Key GraphQL Query IDs** (rotates — extract from `main.bfb69eea.js` when broken):

| Endpoint | Query ID | Guest OK? | Notes |
|----------|---------|-----------|-------|
| UserTweets | `hr4gzZONlq23okjU8fIe_A` | ⚠️ 97 top tweets only | Auth needed for chronological + pagination |
| SearchTimeline | `Bcw3RzK-PatNAmbnw54hFw` | ❌ Empty response | Auth required |
| UserTweetsAndReplies | `FIFgycIi-CNJcV0R-135Uw` | ❌ Blocked | Auth required |

## What Doesn't Work (Guest/Unauthenticated)

- ❌ GraphQL API with guest token: 97 tweets max, engagement-sorted, no pagination cursor
- ❌ syndication.twitter.com: same 97-tweet limit
- ❌ nitter.net: returns HTTP 200 but empty body (nitter is dead)
- ❌ fxtwitter API: profile info only, no timeline

## Usage Pattern

### Search tweets by keyword + date range

```
from:aleabitoreddit NBIS since:2025-09-01 until:2025-10-01
from:username keyword
from:username since:YYYY-MM-DD
```

### Auth headers

```python
headers = {
    "Authorization": f"Bearer {BEARER}",
    "Cookie": f"auth_token={AUTH_TOKEN}; ct0={CT0_TOKEN}",
    "x-csrf-token": CT0_TOKEN,
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}
```

## Tool Choice

**Use `subprocess` + `curl`** for API calls. Python's `urllib` consistently fails with 404/empty responses on X's API through the proxy even when curl succeeds. `requests` library has the same issue. Only curl via subprocess works reliably.

## Pitfalls

- **CSRF mismatch**: `x-csrf-token` header must match the `ct0` cookie value exactly. Getting "This request requires a matching csrf cookie and header" means they don't match.
- **Query IDs expire**: X rotates query IDs periodically. When a 404 appears, re-extract from X's main JS bundle (`https://abs.twimg.com/responsive-web/client-web/main.*.js`). Search for `operationName:"UserTweets"` etc.
- **Token expiry**: auth_token can expire after months. The bot account stays logged in for long periods but not forever. When it fails, re-extract both cookies from browser.
- **Search without auth returns empty**: Not an error — just no results. The guest token limitations are intentional, not a bug.
- **Timeline pagination**: Even with auth, timeline returns ~3200 tweets max. For full history of prolific users (>3200 tweets), use Search endpoint with monthly date slicing.
