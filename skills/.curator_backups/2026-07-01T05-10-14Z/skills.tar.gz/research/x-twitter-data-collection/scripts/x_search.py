"""X Search API — curl-based template for searching tweets.

Requirements: X auth_token (from browser cookies), proxy.
Usage:
    python x_search.py --keyword "NBIS" --since 2025-09-01 --until 2025-10-01
    python x_search.py --keyword "调仓"
"""
import subprocess, json, argparse, urllib.parse, os

PROXY = "http://127.0.0.1:7897"
BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
SEARCH_QID = "Bcw3RzK-PatNAmbnw54hFw"
TARGET_USER = "aleabitoreddit"  # Change as needed


def curl(method, url, headers=None):
    cmd = ["curl", "-sL", "--connect-timeout", "15", "-X", method, "--proxy", PROXY]
    if headers:
        for k, v in headers.items():
            cmd.extend(["-H", f"{k}: {v}"])
    cmd.append(url)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return json.loads(result.stdout) if result.stdout.strip() else {}


def search_tweets(auth_token, keyword, since=None, until=None, count=20, cursor=None):
    """Search tweets with auth token."""
    query_parts = [f"from:{TARGET_USER}"]
    if keyword:
        query_parts.append(keyword)
    if since:
        query_parts.append(f"since:{since}")
    if until:
        query_parts.append(f"until:{until}")
    
    raw_query = " ".join(query_parts)
    
    vars_d = {"rawQuery": raw_query, "count": count, "product": "Latest"}
    if cursor:
        vars_d["cursor"] = cursor
    
    feats = {"responsive_web_graphql_exclude_directive_enabled": True}
    
    url = (
        f"https://x.com/i/api/graphql/{SEARCH_QID}/SearchTimeline"
        f"?variables={urllib.parse.quote(json.dumps(vars_d))}"
        f"&features={urllib.parse.quote(json.dumps(feats))}"
    )
    
    headers = {
        "Authorization": f"Bearer {BEARER}",
        "Cookie": f"auth_token={auth_token}",
        "User-Agent": "Mozilla/5.0"
    }
    
    resp = curl("GET", url, headers)
    
    if 'errors' in resp:
        return [], None, resp['errors']
    
    try:
        timeline = resp['data']['search_by_raw_query']['search_timeline']['timeline']
    except KeyError:
        return [], None, f"KeyError: {list(resp.keys())}"
    
    instructions = timeline['instructions']
    tweets = []
    next_cursor = None
    
    for inst in instructions:
        if inst.get('type') == 'TimelineAddEntries':
            for e in inst['entries']:
                ct = e['content'].get('entryType', '?')
                if ct == 'TimelineTimelineItem':
                    result = e['content']['itemContent']['tweet_results']['result']
                    legacy = result.get('legacy', {})
                    if legacy:
                        tweets.append({
                            'id': legacy.get('id_str'),
                            'created_at': legacy.get('created_at'),
                            'full_text': legacy.get('full_text'),
                            'likes': legacy.get('favorite_count', 0),
                            'retweets': legacy.get('retweet_count', 0),
                            'replies': legacy.get('reply_count', 0),
                            'views': result.get('views', {}).get('count')
                        })
                elif ct == 'TimelineTimelineCursor':
                    if e['content'].get('cursorType') == 'Bottom':
                        next_cursor = e['content'].get('value')
    
    return tweets, next_cursor, None


def load_auth_token(config_path=None):
    """Load auth_token from config file or env var."""
    if config_path is None:
        config_path = os.path.expanduser("~/serenity_config/token.txt")
    
    if os.path.exists(config_path):
        with open(config_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith("AUTH_TOKEN="):
                    return line.split("=", 1)[1].strip('"').strip("'")
    
    return os.environ.get("X_AUTH_TOKEN")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Search X/Twitter tweets")
    parser.add_argument("--keyword", "-k", help="Search keyword")
    parser.add_argument("--since", help="Start date (YYYY-MM-DD)")
    parser.add_argument("--until", help="End date (YYYY-MM-DD)")
    parser.add_argument("--count", "-n", type=int, default=20, help="Results per page")
    parser.add_argument("--pages", "-p", type=int, default=1, help="Number of pages")
    args = parser.parse_args()
    
    auth_token = load_auth_token()
    if not auth_token:
        print("ERROR: No auth_token found. Set X_AUTH_TOKEN env var or create ~/serenity_config/token.txt")
        exit(1)
    
    all_tweets = []
    cursor = None
    
    for page in range(args.pages):
        tweets, cursor, error = search_tweets(
            auth_token, args.keyword, args.since, args.until, args.count, cursor
        )
        
        if error:
            print(f"ERROR: {error}")
            break
        
        all_tweets.extend(tweets)
        print(f"Page {page+1}: {len(tweets)} tweets (total: {len(all_tweets)})")
        
        if not cursor:
            print("No more pages.")
            break
    
    print(f"\n{'='*50}")
    for i, t in enumerate(all_tweets):
        print(f"\n{i+1}. [{t['created_at'][:20]}] ❤️{t['likes']}")
        print(f"   {t['full_text'][:200]}")
