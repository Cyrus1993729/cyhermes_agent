---
name: x-twitter-data-collection
description: "抓取 X/Twitter 推文：timeline、搜索、按关键词/日期筛选。GraphQL API 逆向 + 代理穿透。"
version: 1.0.0
metadata:
  hermes:
    tags: [Twitter, X, Data-Collection, API, Proxy, Social-Media]
---

# X/Twitter 数据采集

从 X/Twitter 抓取推文——用户 timeline、搜索推文、按关键词/日期筛选。

## 核心认知：X 的访问层级

| 访问级别 | UserTweets | Search API | 翻页 | 能拿多少 |
|----------|-----------|------------|------|---------|
| Guest token | ✅ 97条热门 | ❌ 空响应 | ❌ 无 cursor | ~97 |
| Auth token | ✅ 最新~3200 | ✅ 全文搜索 | ✅ 完整分页 | 3200+ |

**结论：任何有意义的采集都需要 auth_token（登录态）。Guest token 被 X 严格限制。**

### 获取 auth_token 的方式
1. **浏览器提取**：F12 → Application/应用 → Cookies → x.com → `auth_token`。中文浏览器：`应用 → 存储 → Cookies → https://x.com`
2. **twscrape 库**：用 bot 账号自动登录，适合全自动化
3. **付费 API**：twitterapi.io 等，零配置但需花钱

---

## 技术要点

### 1. Bearer Token（固定，从 X 主 JS 提取）
从 `abs.twimg.com/responsive-web/client-web/main.*.js` 提取。格式：
```
AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA
```

### 2. Guest Token（临时，会话级）
```bash
curl -sL -X POST "https://api.x.com/1.1/guest/activate.json" \
  -H "Authorization: Bearer $BEARER"
```

### 3. GraphQL Query IDs（需定期从 JS 提取）
从 X 主页 `main.*.js` 中查找：`queryId:"xxx",operationName:"OperationName"`

| 操作 | Query ID |
|------|----------|
| UserTweets | `hr4gzZONlq23okjU8fIe_A` |
| UserTweetsAndReplies | `FIFgycIi-CNJcV0R-135Uw` |
| SearchTimeline | `Bcw3RzK-PatNAmbnw54hFw` |

查找方法：在 JS 中搜索 `operationName:"SearchTimeline"` 找到对应 `queryId`。

### 4. 代理穿透
```bash
export HTTP_PROXY="http://127.0.0.1:7897"
export HTTPS_PROXY="http://127.0.0.1:7897"
```

---

## ⚠️ 关键平台陷阱

### Windows 上 Python urllib/requests 调 X API 返回 404
**症状**：`urllib.request` 和 `requests` 通过代理访问 `api.x.com` 返回 404，但 `curl` 正常。
**原因**：Python SSL/TLS 实现与代理的兼容性。
**解决方案**：用 `subprocess` 调 `curl`，而非 Python HTTP 库。

```python
import subprocess, json

def curl(method, url, headers=None):
    cmd = ["curl", "-sL", "--connect-timeout", "15", "-X", method, "--proxy", PROXY]
    if headers:
        for k, v in headers.items():
            cmd.extend(["-H", f"{k}: {v}"])
    cmd.append(url)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return json.loads(result.stdout) if result.stdout.strip() else {}
```

### Guest API 无翻页 cursor
`UserTweets` 始终返回 ~97 条且无 Bottom cursor。不是代码问题，是 X 故意限制。

### Nitter 公共实例已死
所有实例返回空内容。不用这条路。

### fxtwitter 无 timeline
只有 profile 信息，不支持 timeline 或 search。

### syndication.twitter.com 可用但无优势
同样限制 ~97 条，不比 GraphQL 好。

---

## 已验证的工作流程

### 搜索推文
```
from:aleabitoreddit NBIS since:2025-09-01 until:2025-10-01
from:aleabitoreddit 调仓
```
调用 SearchTimeline 端点，支持关键词 + 日期范围 + 分页。

### Auth Token 有效期
- 每次登录生成新 token
- 通常持续数月
- 改密码或异地登录会使旧 token 失效
- 不同设备 token 不同

---

## 参考文件
- `references/query-id-extraction-guide.md` — 如何从 JS 中提取最新 query ID
- `scripts/x_search.py` — curl-based 搜索脚本模板
