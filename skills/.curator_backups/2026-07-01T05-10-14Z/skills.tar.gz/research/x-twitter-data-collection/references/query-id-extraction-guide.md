# X GraphQL Query ID 提取指南

X 定期更换 GraphQL query ID。当旧 ID 返回 404 时，按以下步骤提取新 ID。

## 步骤

### 1. 下载 X 主页
```bash
export HTTP_PROXY="http://127.0.0.1:7897"
export HTTPS_PROXY="http://127.0.0.1:7897"
curl -sL "https://x.com" -H "User-Agent: Mozilla/5.0" > /tmp/x_home.html
```

### 2. 找到主 JS 文件 URL
```bash
grep -oP 'src="([^"]*main[^"]*\.js[^"]*)"' /tmp/x_home.html
```

### 3. 下载主 JS
```bash
curl -sL "https://abs.twimg.com/responsive-web/client-web/main.bfb69eea.js" > /tmp/x_main.js
```

### 4. 提取需要的 query ID
```bash
# UserTweets
grep -oP 'queryId:"[^"]+",operationName:"UserTweets"' /tmp/x_main.js

# SearchTimeline
grep -oP 'queryId:"[^"]+",operationName:"SearchTimeline"' /tmp/x_main.js

# UserTweetsAndReplies
grep -oP 'queryId:"[^"]+",operationName:"UserTweetsAndReplies"' /tmp/x_main.js
```

### 5. Bearer Token（通常不变）
```bash
grep -oP 'AAAAA[A-Za-z0-9%\-_]{50,}' /tmp/x_main.js
```
