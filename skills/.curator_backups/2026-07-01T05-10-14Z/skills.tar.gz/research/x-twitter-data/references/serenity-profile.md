# Serenity (@aleabitoreddit)

## Profile
- **X handle:** @aleabitoreddit
- **Name:** Serenity
- **User ID:** 1940360837547565056
- **Followers:** ~882,000 (June 2026)
- **Following:** 175
- **Total tweets:** 7,443
- **Media count:** 2,129
- **Joined:** July 2, 2025
- **Verified:** Yes (individual)
- **Location:** NFA

## Bio
> I only use X, beware of imposters.
> AI/Semi Supply Chain Analyst
> Not investment advice, DYODD. Sharing personal thought process on supply chain bottlenecks.

## Nicknames
- "白毛股神" (White-Haired Stock God)
- "推特第一美股股神" (X's #1 US Stock God)

## Core Methodology: Supply Chain Bottleneck Hunting
1. Start from market narrative → translate to systemic change
2. Map full supply chain: downstream demand → system integration → modules → chips → process → equipment → materials
3. Find scarce layers: few suppliers, long certification, hard to expand capacity
4. Build candidate pool (≥20 companies) → multi-source evidence → rank
5. Output: chokepoints, evidence level, what market might be missing, what would prove the thesis wrong

## Key Investment Themes
- **NeoCloud** (highest conviction): NBIS, IREN, CIFR, CRWV, WULF, BITF
- **Connectivity/Semiconductors:** ALAB, CRDO, CLS, TSM, AMD
- **Robotics:** KRKNF, ONDS, RR
- **National Security:** RKLB, MP, KTOS, CCCX
- **Energy:** FLNC, EOSE, TE, SEI

## Notable Positions & Takes
- $NBIS: Largest position, calls it "once-a-decade generational wealth" stock, $400+ PT
- Sold off miners (CIFR, IREN, WULF) for full-stack Neoclouds (NBIS)
- Philosophy: "Margins > Capacity" — favors AWS-style full-stack over pure compute leasing
- Early investor in RKLB, HOOD, TSM, BTC

## Reddit History
Previously posted on Reddit (referenced in his X bio). Username unknown.

## Related Tools
- [serenity-skill](https://github.com/muxuuu/serenity-skill) — Open-source Agent Skill implementing his methodology
- serenity-value — Custom overlay the user developed for deeper analysis
