---
name: x-twitter-data
description: Fetch X (Twitter) user profiles, tweets, and timelines through proxy. Use when the user asks about an X/Twitter account, wants to monitor tweets, or needs to pull tweet history.
---

# X/Twitter Data Fetching

Fetch X/Twitter user profiles, tweets, and timelines programmatically through the local proxy (`127.0.0.1:7897`). Covers profile lookup, GraphQL API usage, tweet extraction, and pagination limits.

## Quick Start

```bash
# Profile info (no auth needed)
export HTTP_PROXY="http://127.0.0.1:7897"
export HTTPS_PROXY="http://127.0.0.1:7897"
curl -sL "https://api.fxtwitter.com/<screen_name>" | python -c "import sys,json; d=json.load(sys.stdin); u=d['user']; print(f\"{u['name']} | {u['followers']} followers | {u['tweets']} tweets\")"
```

## Endpoints Cheat Sheet

| Endpoint | What | Auth | Limit |
|----------|------|------|-------|
| `api.fxtwitter.com/<screen_name>` | Profile info, followers, bio | None | N/A |
| `syndication.twitter.com/srv/timeline-profile/screen-name/<name>` | Embedded timeline widget | None | ~97 tweets, no pagination |
| `x.com/i/api/graphql/<query_id>/UserTweets` | User tweets (GraphQL) | Guest token | ~97 tweets, no pagination for guest |
| `api.x.com/1.1/guest/activate.json` | Activate guest token | Bearer token | N/A |

## Critical Limitation: Guest = 97 Tweets

**All unauthenticated endpoints return exactly ~97 tweets with no pagination cursor.** This is X's hard limit. To get full tweet history (e.g. 7,443 tweets), you need authenticated access. Options:

1. **User auth cookie** — Extract `auth_token` from browser DevTools → Application → Cookies → x.com
2. **X API paid tier** — $100/mo Basic
3. **Playwright browser automation** — Install Playwright, scroll timeline, capture all

When the user asks for full history, present these options — don't keep hitting the guest API expecting different results.

## Proxy: Use curl, Not Python urllib/requests

The proxy at `127.0.0.1:7897` works reliably with **curl** but Python's `urllib.request` and `requests` library both get 404 on `api.x.com/1.1/guest/activate.json`. Use `subprocess.run(["curl", ...])` from Python scripts.

```python
# ✅ Works
import subprocess, json
result = subprocess.run(
    ["curl", "-sL", "--connect-timeout", "15", "-X", "POST",
     "--proxy", "http://127.0.0.1:7897",
     "-H", f"Authorization: Bearer {BEARER}",
     "https://api.x.com/1.1/guest/activate.json"],
    capture_output=True, text=True, timeout=20
)
gt = json.loads(result.stdout)['guest_token']
```

## Bearer Token & Query ID Extraction

X rotates these periodically. Extract from the main JS bundle:

```bash
# 1. Find main JS URL from x.com HTML
curl -sL --proxy http://127.0.0.1:7897 "https://x.com" | \
  grep -oP 'src="([^"]*main[^"]*\.js)' | head -1

# 2. Download JS and extract Bearer token
curl -sL --proxy http://127.0.0.1:7897 "<main_js_url>" | \
  grep -oP 'AAAAA[A-Za-z0-9%\-_]{50,}'

# 3. Extract UserTweets query ID
curl -sL --proxy http://127.0.0.1:7897 "<main_js_url>" | \
  grep -oP 'queryId:"([^"]+)",operationName:"UserTweets"'
```

**Current values (2026-06-24):**
- Bearer: `AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA`
- UserTweets query ID: `hr4gzZONlq23okjU8fIe_A`
- UserTweetsAndReplies query ID: `FIFgycIi-CNJcV0R-135Uw`

## Fetching Tweets via GraphQL

```python
import subprocess, json, urllib.parse, time

BEARER = "..."  # From JS extraction
USER_ID = "..."  # From fxtwitter API
QUERY_ID = "..."  # From JS extraction
PROXY = "http://127.0.0.1:7897"

def curl(method, url, headers=None):
    cmd = ["curl", "-sL", "--connect-timeout", "15", "-X", method, "--proxy", PROXY]
    for k, v in (headers or {}).items():
        cmd.extend(["-H", f"{k}: {v}"])
    cmd.append(url)
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return json.loads(r.stdout) if r.stdout.strip() else {}

# 1. Get guest token
gt = curl("POST", "https://api.x.com/1.1/guest/activate.json",
          headers={"Authorization": f"Bearer {BEARER}"})['guest_token']

# 2. Fetch tweets
vars_d = {"userId": USER_ID, "count": 100, "includePromotedContent": False,
          "withVoice": True, "withV2Timeline": True}
feats = {"responsive_web_graphql_exclude_directive_enabled": True,
         "view_counts_everywhere_api_enabled": True,
         "longform_notetweets_consumption_enabled": True,
         "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True}

qs = f"?variables={urllib.parse.quote(json.dumps(vars_d))}&features={urllib.parse.quote(json.dumps(feats))}"
resp = curl("GET", f"https://x.com/i/api/graphql/{QUERY_ID}/UserTweets{qs}",
            headers={"Authorization": f"Bearer {BEARER}",
                     "x-guest-token": gt,
                     "User-Agent": "Mozilla/5.0"})

# 3. Extract tweets from instructions
timeline = resp['data']['user']['result']['timeline']['timeline']
for inst in timeline['instructions']:
    if inst.get('type') == 'TimelineAddEntries':
        for entry in inst.get('entries', []):
            if entry['content'].get('entryType') == 'TimelineTimelineItem':
                legacy = entry['content']['itemContent']['tweet_results']['result']['legacy']
                print(f"{legacy['created_at']}: {legacy['full_text'][:100]}")
            elif entry['content'].get('entryType') == 'TimelineTimelineCursor':
                cursor_type = entry['content'].get('cursorType')
                # 'Bottom' cursor = pagination. 'Top' = beginning.
                # Guest tokens get NO cursor. Auth tokens get Bottom cursor.
```

## Pitfalls

- **Guest token = 97 tweets max, no pagination.** Do not loop expecting more pages. Tell the user upfront.
- **Python urllib/requests ≠ curl.** The proxy works with curl but Python HTTP libraries get 404 on X's API. Always shell out to curl.
- **Query IDs rotate.** If you get 404 on the GraphQL endpoint, re-extract the current query ID from the main JS bundle.
- **User ID from fxtwitter.** `api.fxtwitter.com/<handle>` returns the numeric user ID needed for GraphQL.
- **Syndication endpoint is also capped at ~97.** It uses `__NEXT_DATA__` JSON in the HTML, but same limit.
- **Rate limits.** X guest APIs have rate limits. Space requests by 1-2 seconds.

## Monitoring an Account

When the user wants to track an X account's tweets:

1. **One-time historical pull** — Present the auth options (cookie, paid API, Playwright). Guest access caps at 97 tweets.
2. **Daily cron monitoring** — After historical data is secured, set up a cron job with the `x-twitter-data` skill loaded. The cron fetches latest tweets, diffs against saved data, and reports new ones.
3. **Always present options as a comparison table** — user prefers systematic trade-off analysis before committing to an approach.

## References

- `references/serenity-profile.md` — Serenity (@aleabitoreddit) profile details and methodology
