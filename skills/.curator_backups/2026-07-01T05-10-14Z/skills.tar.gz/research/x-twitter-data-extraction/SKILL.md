---
name: x-twitter-data-extraction
description: >-
  Extract tweets from X/Twitter users — scraping, monitoring, search. Covers
  Guest token API limits (97 tweets max, no pagination), GraphQL query ID
  discovery, Bearer token extraction from main JS, proxy workarounds (curl
  subprocess vs urllib), and authenticated alternatives (twscrape, paid APIs).
triggers:
  - "抓取 X/Twitter 推文"
  - "监控 X 用户"
  - "爬 X 推文历史"
  - "搜索 X 关键词"
  - "获取 twitter 推文"
  - "from:aleabitoreddit"
  - "serenity 推文"
  - "X API guest token"
  - "GraphQL query ID"
---

# X/Twitter Data Extraction

> ⚠️ **2026-07-01 更新: 首选方案已变**
> X 发布了官方托管 MCP 服务器 (`https://api.x.com/mcp`)，支持 OAuth 2.0 认证，
> 提供搜索、用户查找、趋势、书签等能力。**本 skill 中的 scraping 方案应作为备用 /**
> 补充而非首选。详细配置见 [`references/x-mcp-server.md`](references/x-mcp-server.md)。

## Overview

X (Twitter) blocks unauthenticated access to all meaningful endpoints. Guest
tokens give only ~97 engagement-sorted "Top" tweets with no pagination cursor.
Search returns empty. Syndication is same 97-tweet limit. Nitter is dead.

**For anything beyond 97 tweets, authentication is required.** This skill
documents the Guest token approach (for quick 97-tweet snapshots) and the
authenticated path (twscrape) for full access.

---

## Quick Snapshot: Guest Token (97 tweets, no pagination)

Use this when you just need a user's most popular tweets. Works with no login.

### Step 1: Extract Bearer Token

The Bearer token lives in X's main JS bundle. Find the current bundle:

```bash
# From x.com HTML, find the main JS URL
curl -sL --connect-timeout 15 "https://x.com" \
  -H "User-Agent: Mozilla/5.0" | \
  grep -oP 'src="(https://abs.twimg.com/responsive-web/client-web/main\.[^"]+\.js)"'
```

Then extract the hardcoded token:

```bash
curl -sL "https://abs.twimg.com/responsive-web/client-web/main.bfb69eea.js" | \
  grep -oP 'AAAAA[A-Za-z0-9%\-_]{50,}'
```

This token is stable (doesn't rotate per-session).

### Step 2: Activate Guest Token

```bash
curl -sL -X POST "https://api.x.com/1.1/guest/activate.json" \
  -H "Authorization: Bearer <BEARER_TOKEN>"
# Returns: {"guest_token":"2069..."}
```

### Step 3: Find Current Query IDs

Query IDs rotate per JS bundle. Find them in the main JS:

```bash
curl -sL "https://abs.twimg.com/.../main.bfb69eea.js" | \
  grep -oP '(queryId|operationName):"[^"]+"'
```

Key operations (names stable, IDs rotate):
- `UserTweets` → user timeline
- `UserTweetsAndReplies` → timeline + replies (blocked for guest)
- `SearchTimeline` → search (blocked for guest)

### Step 4: Fetch Tweets

```python
import subprocess, json, urllib.parse

USER_ID = "1940360837547565056"  # from fxtwitter or profile page
QUERY_ID = "hr4gzZONlq23okjU8fIe_A"  # MUST be current! Check JS for updates

vars_d = {"userId": USER_ID, "count": 100, "includePromotedContent": False,
          "withVoice": True, "withV2Timeline": True}
feats = {"responsive_web_graphql_exclude_directive_enabled": True,
         "view_counts_everywhere_api_enabled": True,
         "longform_notetweets_consumption_enabled": True}

url = (f"https://x.com/i/api/graphql/{QUERY_ID}/UserTweets"
       f"?variables={urllib.parse.quote(json.dumps(vars_d))}"
       f"&features={urllib.parse.quote(json.dumps(feats))}")

# Use curl subprocess — Python urllib fails with proxy for POST
cmd = ["curl", "-sL", "--connect-timeout", "15",
       "--proxy", "http://127.0.0.1:7897",
       "-H", f"Authorization: Bearer {BEARER}",
       "-H", f"x-guest-token: {guest_token}",
       url]
result = subprocess.run(cmd, capture_output=True, text=True)
resp = json.loads(result.stdout)

# Parse: resp['data']['user']['result']['timeline']['timeline']['instructions']
```

### Pitfall: Why curl subprocess, not urllib/requests

Python's `urllib` and `requests` libraries return **404** for X API calls
through the proxy (HTTP 127.0.0.1:7897), while `curl` works fine. This appears
to be a TLS/ALPN negotiation issue between Python's SSL stack and the proxy.

**Always use `subprocess.run(["curl", ...])` for X API calls behind a proxy.**

### Limitations

| Endpoint | Guest Access |
|----------|:--:|
| UserTweets | ✅ 97 tweets, engagement-sorted, no pagination cursor |
| UserTweetsAndReplies | ❌ Blocked (empty response) |
| SearchTimeline | ❌ Blocked (empty response) |
| syndication.twitter.com | ✅ Same 97 tweets, cleaner JSON |
| fxtwitter API | ✅ Profile info only, no timeline |

---

## Full Access: twscrape (needs bot account)

For timeline pagination, search, or historical tweets beyond 97, use
[twscrape](https://github.com/vladkens/twscrape) — a Python library that
manages X account pools, handles IMAP email verification, and provides
authenticated API access.

```bash
pip install twscrape
```

The user needs 1 X account (recommend 2-3 for rate-limit rotation). The
account info (username/password/email/email_password) is fed to twscrape,
which auto-logs in via IMAP email verification — zero manual intervention.

### Search by keyword + date range (authenticated)

```python
import asyncio
from twscrape import API, gather

async def search_tweets():
    api = API(proxy="http://127.0.0.1:7897")
    await api.pool.add_account("user", "pass", "email", "emailpass")
    await api.pool.login_all()

    # Search with date range
    results = await gather(api.search(
        "from:aleabitoreddit NBIS since:2025-11-01 until:2025-12-01",
        limit=100
    ))
    for t in results:
        print(f"{t.date} | {t.rawContent[:100]}")
```

### Full timeline (authenticated, ~3200 tweet limit)

```python
user = await api.user_by_login("aleabitoreddit")
tweets = await gather(api.user_tweets(user.id, limit=500))
```

---

## Paid Alternatives (zero login, zero browser)

- **twitterapi.io** — Pay-per-call, has user/tweets with pagination
- **Apify "Twitter Scraper"** — Managed actor, results-based pricing

---

## Finding User IDs

```bash
# Via fxtwitter (no auth needed)
curl -s "https://api.fxtwitter.com/aleabitoreddit" | jq '.user.id'
# → "1940360837547565056"
```

---

## Proxy Check Pattern

Before any X API work, verify the proxy is alive:

```bash
curl -sL --connect-timeout 10 -o /dev/null -w "%{http_code}" \
  --proxy "http://127.0.0.1:7897" "https://api.x.com/1.1/guest/activate.json"
```

Expected: `404` (the GET to guest activate returns 404, that's normal).
POST should return 200 with a `guest_token`.

---

## References

- `references/x-mcp-server.md` — X MCP Server 配置指南（官方托管，2026-07 更新，首选方案）
- `references/twscrape-setup.md` — Full twscrape installation and setup guide (legacy/scraping fallback)
- `references/x-api-endpoints.md` — Detailed endpoint documentation and GraphQL query catalog (legacy/scraping fallback)
