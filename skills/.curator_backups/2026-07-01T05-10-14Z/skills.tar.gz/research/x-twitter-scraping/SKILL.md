---
name: x-twitter-scraping
description: Extract tweets, profiles, and timelines from X/Twitter programmatically. Covers both unauthenticated (guest API, 97-tweet limit) and authenticated (cookie/Playwright) paths.
---

# X/Twitter Data Extraction

Fetch tweets, profile data, and timelines from X (Twitter) through the China proxy (`127.0.0.1:7897`).

## Trigger Conditions

Use this skill when:
- User asks to monitor/summarize an X account's tweets
- Need to extract historical tweets from a specific user
- Building a tweet archiver or daily digest of X content
- Investigating what an X user posts about

## Architecture: Two Paths

| Path | Auth | Capacity | When to Use |
|------|------|----------|-------------|
| **Guest API** | None (guest token) | ~97 top tweets, engagement-sorted | Quick profile scan, recent popular tweets |
| **Playwright** | None (simulates browser) | Full timeline, chronological | Complete history, daily monitoring |

## Path A: Guest GraphQL API (No Auth)

### Step 1: Confirm Proxy
All X API calls MUST go through the proxy:
```bash
export HTTP_PROXY="http://127.0.0.1:7897"
export HTTPS_PROXY="http://127.0.0.1:7897"
```

### Step 2: Extract Bearer Token
Fetch x.com's main JS bundle and extract the bearer token:
```bash
# Get main page
curl -sL --proxy http://127.0.0.1:7897 "https://x.com" > /tmp/x.html
# Extract the JS bundle URL
MAIN_JS=$(grep -oP 'src="(https://abs\.twimg\.com/responsive-web/client-web/main\.[^"]+\.js)"' /tmp/x.html | head -1 | grep -oP 'https://[^"]+')
# Download and extract bearer token
curl -sL --proxy http://127.0.0.1:7897 "$MAIN_JS" | grep -oP 'AAAAA[A-Za-z0-9%\-_]{50,}'
```

The bearer token is stable for weeks, not per-session. Current token in `references/bearer-token.md`.

### Step 3: Activate Guest Token
```bash
curl -sL -X POST "https://api.x.com/1.1/guest/activate.json" \
  -H "Authorization: Bearer <BEARER_TOKEN>" \
  --proxy http://127.0.0.1:7897
```

### Step 4: Find Current Query IDs
X rotates GraphQL query IDs. Extract them from the main JS bundle:
```bash
curl -sL --proxy http://127.0.0.1:7897 "$MAIN_JS" | \
  grep -oP 'queryId:"([^"]+)",operationName:"UserTweets[^"]*"'
```

Current query IDs in `references/query-ids.md`.

### Step 5: Fetch UserTweets
```
GET https://x.com/i/api/graphql/{QUERY_ID}/UserTweets
  ?variables={"userId":"...","count":100,...}
  &features={...}
Headers: Authorization: Bearer <BEARER>, x-guest-token: <GUEST_TOKEN>
```

### CRITICAL: Use Curl, NOT Python urllib/requests

**Python's `urllib.request` and `requests` library both fail with 404 on X's API through this proxy**, even though curl works identically. Root cause unknown (likely SSL/TLS negotiation difference between curl's schannel and Python's ssl backend).

✅ **ALWAYS use `subprocess.run(["curl", ...])` from Python** — NOT `urllib.request` or `requests`.

```python
import subprocess, json

def x_api_call(url, method='GET', headers=None):
    cmd = ["curl", "-sL", "--connect-timeout", "15", "-X", method,
           "--proxy", "http://127.0.0.1:7897"]
    if headers:
        for k, v in headers.items():
            cmd.extend(["-H", f"{k}: {v}"])
    cmd.append(url)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return json.loads(result.stdout) if result.stdout.strip() else {}
```

### Limitations of Guest API
- **Maximum ~97 tweets** — hard limit, no pagination cursor returned
- **Engagement-sorted** (Top tweets), NOT chronological
- **No UserTweetsAndReplies** — that endpoint is blocked for guests
- Good for: quick profile scan, extracting most popular content
- Not good for: full history, chronological timeline, recent posts

## Path B: Playwright Browser Automation (Full Access)

For complete timeline access (chronological, full history), use Playwright to simulate a real browser:

### Installation
```bash
uv pip install playwright
playwright install chromium
```

### Core Pattern
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(
        proxy={"server": "http://127.0.0.1:7897"},
        headless=True
    )
    page = browser.new_page()
    page.goto(f"https://x.com/{username}")
    page.wait_for_selector('[data-testid="tweetText"]', timeout=15000)
    
    # Scroll to load more tweets
    for _ in range(scroll_count):
        page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        page.wait_for_timeout(2000)
    
    # Extract tweets
    tweets = page.query_selector_all('[data-testid="tweet"]')
    for tweet in tweets:
        text = tweet.query_selector('[data-testid="tweetText"]').inner_text()
        # ... extract time, stats, etc.
    
    browser.close()
```

### When to Use Playwright
- ✅ Full timeline access (chronological, all tweets)
- ✅ Daily monitoring (can pick up latest tweets)
- ✅ No auth required (anonymous browsing)
- ⚠️ Slower than API (~2s per scroll, 100 tweets per scroll)
- ⚠️ ~150MB Chromium download on first install

## Common Pitfalls

1. **Query ID rotation**: X updates query IDs periodically. If API returns 404, re-extract from main JS bundle.
2. **Guest token expiry**: Tokens last ~1 hour. Refresh before each batch job.
3. **97-tweet limit confusion**: The API returning exactly 97 tweets is NOT a pagination issue — it's a hard guest limit. Switch to Path B.
4. **Python HTTP libraries failing**: Both `urllib` and `requests` fail with 404 on X API through this proxy. Only curl works.
5. **Nitter is dead**: All known Nitter instances return empty content or browser verification. Don't waste time on it.
6. **Syndication endpoint**: `syndication.twitter.com` returns the same 97-tweet limit as the GraphQL API. Not a workaround.

## Support Files

- `references/bearer-token.md` — Current bearer token and extraction method
- `references/query-ids.md` — Current GraphQL query IDs
- `references/serenity-archive.md` — Serenity (@aleabitoreddit) profile and archive notes
- `scripts/fetch_tweets_guest.py` — Guest API tweet fetcher (curl-backed, with pagination stubs)
- `scripts/debug_guest_api.py` — Debug script for testing API endpoints
