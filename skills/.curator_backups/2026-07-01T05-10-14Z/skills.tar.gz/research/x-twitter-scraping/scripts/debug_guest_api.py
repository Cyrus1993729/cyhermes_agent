"""
X/Twitter Guest API debugger — tests all endpoints for a given user.
Call: python scripts/debug_guest_api.py [screen_name]
"""
import subprocess, json, urllib.parse, sys

BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
PROXY = "http://127.0.0.1:7897"

def curl(method, url, headers=None):
    cmd = ["curl", "-sL", "--connect-timeout", "15", "-X", method, "--proxy", PROXY]
    if headers:
        for k, v in headers.items():
            cmd.extend(["-H", f"{k}: {v}"])
    cmd.append(url)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return json.loads(result.stdout) if result.stdout.strip() else {}

def get_user_id(screen_name):
    """Get user ID from fxtwitter."""
    resp = curl("GET", f"https://api.fxtwitter.com/{screen_name}")
    return resp.get('user', {}).get('id', '')

def debug(user_id):
    guest = curl("POST", "https://api.x.com/1.1/guest/activate.json",
                 headers={"Authorization": f"Bearer {BEARER}"})['guest_token']
    hdrs = {"Authorization": f"Bearer {BEARER}", "x-guest-token": guest, "User-Agent": "Mozilla/5.0"}
    feats = {"responsive_web_graphql_exclude_directive_enabled": True,
             "view_counts_everywhere_api_enabled": True}

    print(f"User ID: {user_id}")
    print(f"Guest token: {guest[:20]}...\n")

    # Test UserTweets
    print("=== UserTweets ===")
    vars_d = {"userId": user_id, "count": 5, "includePromotedContent": False,
              "withVoice": True, "withV2Timeline": True}
    qs = f"?variables={urllib.parse.quote(json.dumps(vars_d))}&features={urllib.parse.quote(json.dumps(feats))}"
    resp = curl("GET", f"https://x.com/i/api/graphql/hr4gzZONlq23okjU8fIe_A/UserTweets{qs}", headers=hdrs)
    
    if 'errors' in resp:
        print(f"  ERROR: {resp['errors']}")
    else:
        tl = resp['data']['user']['result']['timeline']['timeline']
        cursors = []
        tweet_count = 0
        for inst in tl['instructions']:
            if inst['type'] == 'TimelineAddEntries':
                for e in inst['entries']:
                    ct = e['content'].get('entryType','?')
                    if ct == 'TimelineTimelineItem':
                        tweet_count += 1
                        legacy = e['content']['itemContent']['tweet_results']['result'].get('legacy',{})
                        if legacy and tweet_count <= 3:
                            print(f"  {legacy['created_at'][:20]} | ❤️{legacy.get('favorite_count',0):4d} | {legacy.get('full_text','')[:70]}...")
                    elif ct == 'TimelineTimelineCursor':
                        cursors.append(e['content'].get('cursorType'))
        print(f"  Total: {tweet_count} tweets, cursors: {cursors}")

    # Test UserTweetsAndReplies
    print("\n=== UserTweetsAndReplies ===")
    vars_d = {"userId": user_id, "count": 5, "includePromotedContent": False,
              "withCommunity": True, "withVoice": True, "withV2Timeline": True}
    qs = f"?variables={urllib.parse.quote(json.dumps(vars_d))}&features={urllib.parse.quote(json.dumps(feats))}"
    resp = curl("GET", f"https://x.com/i/api/graphql/FIFgycIi-CNJcV0R-135Uw/UserTweetsAndReplies{qs}", headers=hdrs)
    if 'data' in resp:
        print(f"  ✅ Working, data returned")
    else:
        print(f"  ❌ Blocked for guest access")

if __name__ == '__main__':
    screen_name = sys.argv[1] if len(sys.argv) > 1 else 'aleabitoreddit'
    uid = get_user_id(screen_name)
    debug(uid)
