# X/Twitter Bearer Token

**Current token** (extracted 2026-06-24):
```
AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA
```

**Extraction method:**

1. Fetch x.com main page to get the JS bundle URL:
```bash
curl -sL --proxy http://127.0.0.1:7897 "https://x.com" | \
  grep -oP 'src="(https://abs\.twimg\.com/responsive-web/client-web/main\.[^"]+\.js)"' | \
  head -1
```

2. Fetch the JS bundle and extract the bearer token:
```bash
curl -sL --proxy http://127.0.0.1:7897 "$MAIN_JS_URL" | \
  grep -oP 'AAAAA[A-Za-z0-9%\-_]{50,}'
```

The token is a static value embedded in the client JS bundle — it changes only when X pushes a new frontend build (every few weeks).
