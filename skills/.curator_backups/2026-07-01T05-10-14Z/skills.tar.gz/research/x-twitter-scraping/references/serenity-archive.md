# Serenity (@aleabitoreddit) Archive

## Profile
- **Name**: Serenity
- **Handle**: @aleabitoreddit
- **User ID**: `1940360837547565056`
- **Joined**: 2025-07-02
- **Followers**: ~882,000 (as of 2026-06-24)
- **Following**: 175
- **Total tweets**: 7,443
- **Bio**: "I only use X, beware of imposters. AI/Semi Supply Chain Analyst. Not investment advice, DYODD. Sharing personal thought process on supply chain bottlenecks."

## Known Aliases
- "白毛股神" (White-Haired Stock God) — Chinese media nickname
- "推特第一美股股神" — dubbed "Twitter's #1 US Stock God"

## Content
- Primary focus: AI/Semiconductor supply chain bottleneck analysis
- NeoCloud thesis (NBIS, IREN, CIFR, WULF, etc.)
- Weekly market analysis with Strong Buy/Buy/Hold/Sell ratings
- Portfolio weighting and position updates
- Methodological posts on swing trading, covered calls, tax structuring

## Archive Status
| Date | Action | Result |
|------|--------|--------|
| 2026-06-24 | Guest API fetch | 97 top tweets (2025-09-12 → 2025-11-14), engagement-sorted |
| 2026-06-24 | Playwright approach | Identified as needed for full history |

## Key Stocks He Pushes
- $NBIS (Nebius) — highest conviction, 30% of his model portfolio
- $IREN, $CIFR, $WULF — NeoCloud plays
- $CRDO, $ALAB — connectivity
- $RKLB — space/national security
- $TSM, $AMD — semiconductors
- $FLNC, $EOSE — energy

## Notes
- Joined X monetization program (publicly disclosed)
- Claims 630.44% 1-year return (Sep 2025)
- Hates pump-and-dump accounts, frequently calls them out
- All analysis is "not investment advice, DYODD"
- Reddit background before X fame
