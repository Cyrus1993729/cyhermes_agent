# X GraphQL Query IDs

**Last updated: 2026-06-24**

## Active Query IDs

| Operation | Query ID | Status |
|-----------|----------|--------|
| `UserTweets` | `hr4gzZONlq23okjU8fIe_A` | ✅ Working (guest OK) |
| `UserTweetsAndReplies` | `FIFgycIi-CNJcV0R-135Uw` | ❌ Blocked for guests |

## Extraction Method

From the main JS bundle:
```bash
MAIN_JS="https://abs.twimg.com/responsive-web/client-web/main.bfb69eea.js"
curl -sL --proxy http://127.0.0.1:7897 "$MAIN_JS" | \
  grep -oP 'queryId:"([^"]+)",operationName:"UserTweets[^"]*"'
```

X rotates query IDs with frontend builds. If API returns 404, re-extract.

## Features Parameter

Minimum required features for guest API calls:
```json
{
  "responsive_web_graphql_exclude_directive_enabled": true,
  "view_counts_everywhere_api_enabled": true,
  "longform_notetweets_consumption_enabled": true,
  "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": true
}
```

## User ID Reference

Per-user IDs are stable. Find via fxtwitter:
```bash
curl -s --proxy http://127.0.0.1:7897 \
  "https://api.fxtwitter.com/{screen_name}" | jq '.user.id'
```
