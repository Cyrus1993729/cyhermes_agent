---
name: x-twitter-scraper
description: Scrape X/Twitter user timelines and search tweets using authenticated GraphQL API. Covers guest vs auth limits, token management, proxy setup, and the curl workaround for Python's urllib bug.
triggers:
  - "搜他/她的X推文"
  - "监控这个X账号"
  - "抓取Twitter时间线"
  - "search tweets from @user"
  - "Serenity / aleabitoreddit"
---

# X/Twitter Scraper

Access X/Twitter user timelines and search via the internal GraphQL API through a proxy.

## Guest vs Authenticated Access

| Capability | Guest Token | Auth Token (cookie) |
|---|---|---|
| UserTweets | 97 tweets, engagement-sorted | ✅ Full timeline + pagination cursors |
| UserTweetsAndReplies | ❌ Blocked | ✅ Works |
| SearchTimeline | ❌ Empty response | ❌ Empty response (even with auth) |
| Syndication embed | 97 tweets | Same |

**Bottom line**: Guest token is useless for anything beyond a ~97-tweet sample. Authenticated access (auth_token + ct0 cookie) unlocks full timeline pagination. Search endpoint doesn't work either way.

## Setup

### 1. Proxy

All X API calls must go through the proxy `127.0.0.1:7897`.

### 2. Credentials

Create a bot X account (not the user's personal account). Extract two cookies from Chrome DevTools after logging in:

   - `auth_token` (32-char hex)
   - `ct0` (long hex string, used as CSRF token)

Store them in a local config file:
```
AUTH_TOKEN="abc123..."
CT0_TOKEN="def456..."
```

### 3. API Parameters

**Bearer token** (constant, extracted from X's main JS bundle):
```
AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA
```

**Query IDs** (change when X updates their frontend — re-extract from main JS):
- UserTweets: `hr4gzZONlq23okjU8fIe_A`
- UserTweetsAndReplies: `FIFgycIi-CNJcV0R-135Uw`
- SearchTimeline: `Bcw3RzK-PatNAmbnw54hFw`

To find current Query IDs: fetch `https://abs.twimg.com/responsive-web/client-web/main.<hash>.js` and search for `operationName:"UserTweets"`.

### 4. Headers

```python
headers = {
    "Authorization": f"Bearer {BEARER}",
    "Cookie": f"auth_token={AUTH_TOKEN}; ct0={CT0}",
    "x-csrf-token": CT0,
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}
```

## Critical: Use curl, not urllib

Python's `urllib.request` and `requests` library BOTH fail with HTTP 404 on X API endpoints, even though curl works fine. Root cause unknown — likely TLS/ALPN negotiation difference.

**Always use `subprocess` to call `curl`:**

```python
def curl(method, url, headers=None):
    cmd = ["curl", "-sL", "--connect-timeout", "15", "-X", method,
           "--proxy", "http://127.0.0.1:7897"]
    if headers:
        for k, v in headers.items():
            cmd.extend(["-H", f"{k}: {v}"])
    cmd.append(url)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    return json.loads(result.stdout) if result.stdout.strip() else {}
```

## Timeline Pagination

The `UserTweets` endpoint supports cursor-based pagination via `TimelineTimelineCursor` with `cursorType: "Bottom"`. Each page returns ~17-19 tweets (despite requesting more). Cursor values look like `DAAHCgABHLk6lzx__-wLAAIAAAATMj`.

```python
vars_d = {"userId": USER_ID, "count": 100, "includePromotedContent": False,
          "withVoice": True, "withV2Timeline": True}
if cursor:
    vars_d["cursor"] = cursor
```

Continue paginating until no Bottom cursor is returned.

## Workaround for Search

Since `SearchTimeline` returns empty even with auth, implement local search:
1. Pull timeline tweets via `UserTweets` with pagination
2. Filter by keyword/date range locally in Python
3. Cache results for repeated queries

## Pitfalls

- Token expiry: auth_token can expire. User needs to re-extract from browser if API returns auth errors.
- CSRF mismatch: The `x-csrf-token` header MUST match the `ct0` cookie value, or X returns "This request requires a matching csrf cookie and header".
- Bash escaping: Do NOT try to pass tokens through bash variables in multiline commands. Use Python scripts with file-based token loading.
- Query ID rotation: X periodically changes GraphQL query IDs. When endpoints return 404, re-extract from the main JS bundle.

## References

- `references/x-api-reverse-engineering.md` — Full session transcript of the reverse-engineering process
