# X API Reverse Engineering Notes

## Session: 2026-06-24, Serenity (@aleabitoreddit)

### Discovery Path

1. **Guest token activation**: `POST api.x.com/1.1/guest/activate.json` → returns `guest_token`
2. **Bearer token**: Extracted from `abs.twimg.com/responsive-web/client-web/main.*.js` — fixed constant
3. **Query IDs**: Found by searching main JS for `operationName:"UserTweets"` etc.

### What Failed

| Approach | Result | Root Cause |
|----------|--------|------------|
| Guest token + UserTweets | 97 tweets, no cursor | X hard-limits unauthenticated access |
| Guest token + SearchTimeline | Empty response | Search requires login |
| Auth + SearchTimeline | Empty response | Unknown — even auth doesn't enable search |
| Python `urllib` | HTTP 404 | TLS/ALPN incompatibility with proxy? |
| Python `requests` | HTTP 404 | Same issue |
| nitter.net RSS | HTTP 200, empty body | Nitter public instances dead |
| fxtwitter API | Profile only | No timeline endpoint |

### What Worked

| Approach | Result |
|----------|--------|
| `curl` + proxy + auth_token + ct0 + UserTweets | ✅ Full timeline + pagination cursors |
| fxtwitter.com profile | ✅ User stats (followers, bio, etc.) |
| syndication.twitter.com embed | ✅ 97 tweets (no auth) |

### Proxy

- Address: `http://127.0.0.1:7897`
- Required for all X API access
- Works with `curl --proxy` flag
- Does NOT work with Python `urllib` or `requests` (404)
- Does NOT work with Playwright directly (needs browser-level proxy config)

### Token Extraction (Chrome Chinese UI)

```
右键 → 检查 / Ctrl+Shift+I → 应用 → 存储 → Cookies → https://x.com
```
Find: `auth_token` and `ct0`

### Timeline Response Structure
```
data.user.result.timeline.timeline.instructions[]
  └─ TimelineAddEntries
       ├─ TimelineTimelineItem → itemContent.tweet_results.result.legacy
       └─ TimelineTimelineCursor → cursorType: "Bottom"|"Top"
```

### Serenity Profile
- User ID: `1940360837547565056`
- Screen name: `aleabitoreddit`  
- Joined: 2025-07-02
- Tweets: 7,443
- Followers: ~882k
- Bio: "AI/Semi Supply Chain Analyst"
- Also known as: 白毛股神, "推特第一美股股神"
