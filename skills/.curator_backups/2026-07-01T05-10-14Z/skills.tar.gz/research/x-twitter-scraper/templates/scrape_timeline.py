"""
X/Twitter timeline scraper — copy & modify for any target user.

Prerequisites:
  1. Create token.txt with AUTH_TOKEN and CT0_TOKEN
  2. Set TARGET_USER_ID, OUTPUT_FILE, MAX_PAGES below
"""
import subprocess, json, urllib.parse, time, os

# === CONFIGURATION ===
BEARER = "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
QUERY_ID = "hr4gzZONlq23okjU8fIe_A"  # UserTweets — re-extract from main JS if 404
PROXY = "http://127.0.0.1:7897"
TOKEN_FILE = os.path.expanduser(r"~\serenity_config\token.txt")
TARGET_USER_ID = "1940360837547565056"  # Change for different user
OUTPUT_FILE = os.path.expanduser(r"~\tweets_output.jsonl")
MAX_PAGES = 50  # ~800-1000 tweets, adjust as needed

# === LOAD TOKENS ===
AUTH_TOKEN=*** = ""
with open(TOKEN_FILE) as f:
    for line in f:
        parts = line.strip().split('"')
        if len(parts) >= 3:
            if parts[0].startswith("AUTH_TOKEN"): AUTH_TOKEN=parts[1]
            if parts[0].startswith("CT0_TOKEN"): CT0 = parts[1]

# === CURL HELPER ===
def curl(method, url, headers=None):
    cmd = ["curl", "-sL", "--connect-timeout", "15", "-X", method, "--proxy", PROXY]
    if headers:
        for k, v in headers.items():
            cmd.extend(["-H", f"{k}: {v}"])
    cmd.append(url)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
    if not result.stdout.strip():
        return {}
    return json.loads(result.stdout)

hdrs = {
    "Authorization": f"Bearer {BEARER}",
    "Cookie": f"auth_token={AUTH_TOKEN}; ct0={CT0}",
    "x-csrf-token": CT0,
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
}

FEATS = {"responsive_web_graphql_exclude_directive_enabled": True,
         "view_counts_everywhere_api_enabled": True,
         "longform_notetweets_consumption_enabled": True}

# === MAIN LOOP ===
cursor = None
page = 0
total = 0
seen_ids = set()

# Resume from existing output
if os.path.exists(OUTPUT_FILE):
    with open(OUTPUT_FILE) as f:
        for line in f:
            if line.strip():
                t = json.loads(line)
                seen_ids.add(t.get('id',''))

with open(OUTPUT_FILE, 'a', encoding='utf-8') as out:
    while page < MAX_PAGES:
        page += 1
        vars_d = {"userId": TARGET_USER_ID, "count": 100,
                  "includePromotedContent": False,
                  "withVoice": True, "withV2Timeline": True}
        if cursor:
            vars_d["cursor"] = cursor
        
        qs = f"?variables={urllib.parse.quote(json.dumps(vars_d))}&features={urllib.parse.quote(json.dumps(FEATS))}"
        resp = curl("GET", f"https://x.com/i/api/graphql/{QUERY_ID}/UserTweets{qs}", headers=hdrs)
        
        if not resp or 'errors' in resp:
            print(f"ERROR page {page}: {resp.get('errors','')}")
            break
        
        tl = resp['data']['user']['result']['timeline']['timeline']
        instructions = tl['instructions']
        
        count = 0
        bottom = None
        first_date = last_date = "?"
        
        for inst in instructions:
            if inst['type'] == 'TimelineAddEntries':
                for e in inst['entries']:
                    ct = e['content'].get('entryType','?')
                    if ct == 'TimelineTimelineItem':
                        result = e['content']['itemContent']['tweet_results']['result']
                        legacy = result.get('legacy',{})
                        if legacy and legacy.get('id_str') not in seen_ids:
                            tweet = {
                                'id': legacy.get('id_str'),
                                'created_at': legacy.get('created_at'),
                                'full_text': legacy.get('full_text'),
                                'favorite_count': legacy.get('favorite_count',0),
                                'retweet_count': legacy.get('retweet_count',0),
                                'reply_count': legacy.get('reply_count',0),
                                'view_count': result.get('views',{}).get('count'),
                            }
                            out.write(json.dumps(tweet, ensure_ascii=False) + '\n')
                            seen_ids.add(tweet['id'])
                            count += 1
                            d = tweet['created_at'][:10]
                            if first_date == "?": first_date = d
                            last_date = d
                    elif ct == 'TimelineTimelineCursor':
                        if e['content'].get('cursorType') == 'Bottom':
                            bottom = e['content'].get('value','')
        
        total += count
        print(f"Page {page}: {count} new | {last_date} → {first_date} | total: {total}")
        
        if not bottom:
            print("End of timeline.")
            break
        
        cursor = bottom
        time.sleep(1)

print(f"\nDone: {total} tweets saved to {OUTPUT_FILE}")
