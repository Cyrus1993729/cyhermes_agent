---
name: claude-code-workflow
description: User-specific workflow rules for orchestrating Claude Code via Hermes Agent. Covers model selection protocol, progress reporting, and action-confirmation requirements. Load alongside claude-code skill whenever delegating tasks to Claude Code.
license: MIT
compatibility: Hermes Agent → Claude Code CLI
metadata:
  author: user-custom
  version: "1.5.0"
  last_updated: "2026-06-29"
  changelog: "Rule 0 升级为🔴红线：多次无代理直连可能导致封号。增加调用前强制检查（代理存活+env var）。修正 diagnosis reference file（403根因=漏代理，非Google Play权限）。"
---

# Claude Code Workflow Rules

User-specific rules for how Hermes Agent should orchestrate Claude Code. These rules apply every time Claude Code is invoked, regardless of the task.

## Rule 0: Proxy — 🔴 RED LINE

**🔴 多次无代理直连 Claude Code 可能导致 Anthropic 封号。这是用户明确划定的红线。**

Claude Code CLI (Node.js) 不会自动走系统代理。从中国直连 `api.anthropic.com` → 区域封锁 → 403。多次裸连积累异常流量可能触发账号安全审查。

### 调用前强制检查

每次调 `claude` 之前：
1. 确认代理存活：`curl -s --proxy http://127.0.0.1:7897 https://api.anthropic.com -o /dev/null -w "%{http_code}"`
2. 确认 env var 已 export：`echo $HTTP_PROXY $HTTPS_PROXY` 不为空
3. **代理挂了 → 宁可放弃本轮调用，也不裸连**

### 正确调用格式

```bash
export HTTP_PROXY="http://127.0.0.1:7897" HTTPS_PROXY="http://127.0.0.1:7897" && claude -p "..." --model opus --max-turns N --output-format text
```

### 代理持久化

代理变量已通过 `setx` 写入 Windows 注册表（`HKCU\Environment`）。**换端口时需两处同步更新：**
- 注册表：`setx HTTPS_PROXY "http://127.0.0.1:<新端口>"`
- 当前终端：`export HTTPS_PROXY="http://127.0.0.1:<新端口>"`

### 可用路径

| 路径 | 状态 | 说明 |
|------|------|------|
| Claude Code CLI (`claude -p`) | ✅ 可用 | 需代理。Google Play Pro 订阅含 CLI 权限。6/16→6/27 连续 11 天正常 |
| Anthropic Direct API | ❌ 403 | Google Play 订阅不含 API key 权限 |
| Hermes Nous Provider | ❌ 余额不足 | OAuth 已配，需在 portal.nousresearch.com 充值 |

### 故障排查速查

403 时按顺序排查：① 代理是否 export？② 代理是否存活？③ 端口是否正确？→ 参见 `references/claude-code-auth-diagnosis.md`

## Rule 1: Model Selection Protocol

**CRITICAL — never change the model without explicit user approval.**

- If the user specifies a model (e.g., "用 Opus 跑"), use exactly that model. Do not downgrade or switch.
- If the first run with the user's chosen model appears slow or produces no output, do NOT silently switch to a faster model (Sonnet, Haiku, etc.). Instead:
  1. Wait a reasonable time (at least 5 minutes for deep research tasks)
  2. Report the status to the user
  3. ASK the user whether they want to continue waiting, switch models, or try another approach
- The user may have reasons for choosing a specific model (deeper reasoning, different strengths) that the agent should not override.

## Rule 2: Action Confirmation Protocol

**CRITICAL — confirm the approach before executing, especially for modifications.**

- Before making ANY change to files, configuration, installed skills, or running any action that has side effects, state the plan and ask for confirmation.
- This includes but is not limited to:
  - Modifying skill files (even user-created ones)
  - Changing Claude Code flags or parameters
  - Installing or removing software
  - Modifying project configuration
- The only exception is when the user explicitly says "just do it" or equivalent.

## Rule 3: Progress Reporting During Long Tasks

**CRITICAL — provide periodic status updates during long-running tasks.**

- When Claude Code is running a deep research task (web searches, multiple turns), check progress every 2-3 minutes.
- Report to the user:
  - That the task is still running
  - How long it has been running
  - Any visible progress (e.g., "first turn complete, now searching")
- If the task has been running with zero visible output for >5 minutes, flag this to the user and ask how to proceed.
- Do NOT leave the user wondering whether the task is alive or dead.

## Rule 5: L2 Independent Review Pattern（Claude 独立评审模式）

**When making a consequential decision about a tool/framework/approach, ask Claude (Sonnet) for an independent judgment before committing.**

Applicable when:
- Evaluating whether to adopt/install a new tool
- Assessing a technical recommendation you've made
- The user is uncertain and wants a second opinion

The pattern (4 steps):
1. **Present the case to Claude** — describe the context, your own analysis, and your recommendation
2. **Ask explicitly for disagreement** — "请给出你的独立意见（同意/不同意/部分同意，并解释理由）" and "我的分析有没有遗漏或偏差？"
3. **Use `--model sonnet`** for L2 (quick validation), `--model opus` for L3 (new-domain framework design). The user decides which.
4. **Synthesize** — compare Claude's judgment against yours, identify blind spots, present the final recommendation.

**Key principle:** Claude should be asked to *judge your recommendation*, not to make the recommendation from scratch. This surfaces blind spots you missed. See `references/l2-independent-review-pattern.md` for the full template.

## Rule 6: Skill Modification Protection

**Do not modify installed skills without explicit user permission.**

- Skills installed from external sources (like serenity-skill from GitHub) represent the author's methodology. The user has chosen to use them as-is.
- If the user wants to extend a skill's behavior, create a NEW companion skill rather than modifying the original.
- If a modification is accidentally made, revert it immediately when the user objects.

## Rule 7: Skill Conflict — Concrete Examples Override Abstract Rules

**When multiple skills are loaded together, a concrete example in one skill will almost always override an abstract constraint in another skill or in the user's prompt.**

This is a fundamental LLM attention pattern, not a skill bug:

- A skill that says *"A-share AI semiconductor → start with memory interconnect"* (concrete) overrides a companion skill that says *"lock to user's market and scope"* (abstract).
- A skill with a full worked example of "US storage chain" biases the model toward storage, even when the user prompt says "A-share AI chips only, no storage."

**Prevention checklist — run before launching multi-skill Claude Code tasks:**

1. **Pre-scan for hard anchors** — check both skills for concrete examples that could compete with the user's intended direction.
2. **Put constraints in the prompt itself** — "仅限A股，禁止美股/存储链" must be in the `claude -p "..."` text, not just in a skill overlay's abstract rules.
3. **Use negative examples** — "研究 AI 算力芯片，不要研究 HBM/存储/内存，这是两个不同的产业链" — a concrete "don't do X" competes with the skill's concrete "do X."
4. **If drift happens twice**, the upstream skill's concrete anchor is too strong — report to user and propose editing the offending lines (with permission).

**If drift persists even with prompt-level constraints, apply the overlay three-part fix (validated 2026-06-23):**

1. **Concrete-to-concrete** — put an equally specific positive example in the overlay (not just a ban) that points to the correct direction.
2. **Explicit supersede** — name the offending skill section by line number and declare it void under this overlay.
3. **Keyword guardrail** — list forbidden keywords (Micron/HBM/NAND) and auto-reject output that contains them.

See `references/skill-drift-pink-elephant.md` for the full case study.

**This is NOT a bug in any specific skill** — it's how LLMs weigh concrete vs abstract instructions. Every multi-skill task carries this risk.

## Bundled Resources

- `references/claude-code-auth-diagnosis.md` — full step-by-step protocol for diagnosing Claude Code CLI auth failures (403, eligibility, OAuth token state). Load when `claude -p` returns auth errors.
- `references/cyclical-valuation-pitfalls.md` — valuation methodology pitfalls for cyclical stocks (semiconductors, storage, energy). Load when doing investment research on cyclical sectors.
- `references/l2-independent-review-pattern.md` — template for asking Claude Sonnet to independently review a technical decision before committing. Use when evaluating tools/frameworks/approaches.
- `references/skill-drift-pink-elephant.md` — real-world case study (2026-06-23): serenity-value × serenity-skill drift, root cause analysis by Claude Opus, and the three-part fix (concrete-to-concrete + explicit supersede + keyword guardrail).
- `references/tool-preinstall-checklist.md` — 4-step checklist (backup → source inspection → uninstall verification → isolation test) before installing any new tool.
- `references/opus-source-debugging.md` — Opus 4.8 源码只读排查模式：5 次尝试的失败教训 → 正确的烟雾测试→简化提示词→参数组合流程。2026-06-27 实践验证。
