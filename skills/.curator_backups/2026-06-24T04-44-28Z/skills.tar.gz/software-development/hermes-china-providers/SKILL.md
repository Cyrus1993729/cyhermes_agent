---
name: hermes-china-providers
description: >-
  Configure and troubleshoot Hermes model providers that have separate 
  China and international endpoints — Moonshot/Kimi, MiniMax, Z.AI/GLM, etc.
  Covers endpoint mismatch 401 errors, China-platform vs international-platform 
  key compatibility, and provider selection for auxiliary tasks (vision, 
  compression, extraction).
triggers:
  - "kimi key 失效"
  - "moonshot 401"
  - "视觉识别不了"
  - "vision failed 401 moonshot"
  - "key 刚申请但报 Invalid Authentication"
  - Configuring moonshot/kimi/minimax as main or auxiliary provider
  - Switching between China and international providers
---

# Hermes China Providers

## Overview

Model providers with dual endpoints (China platform vs international platform)
require correct provider selection in Hermes. A key issued on one platform will
return **401 "Invalid Authentication"** on the other — even when the key is
fresh and valid.

## Provider → Endpoint Mapping

| Hermes Provider | Endpoint | Platform |
|-----------------|----------|----------|
| `moonshot` | `api.moonshot.ai/v1` | 国际站 |
| `moonshot-cn` | `api.moonshot.cn/v1` | 中国站 |
| `kimi` (alias) | → `moonshot` | 国际站 |
| `kimi-cn` (alias) | → `moonshot-cn` | 中国站 |

Note: `kimi-coding` / `kimi-coding-cn` are the internal Hermes provider IDs
that `moonshot` / `moonshot-cn` resolve to. They use the OpenAI-compatible
endpoint (`/v1`), NOT the Kimi Coding Plan (`api.kimi.com/coding`).

## Environment Variable Mapping

Each provider reads a specific env var — **this is the #1 pitfall**:

| Hermes Provider | Env Var It Reads | Endpoint |
|-----------------|-----------------|----------|
| `moonshot` | `KIMI_API_KEY` | `api.moonshot.ai` (国际站) |
| `moonshot-cn` | `KIMI_CN_API_KEY` | `api.moonshot.cn` (中国站) |

**Common trap**: User has a China-platform key stored in `KIMI_API_KEY`,
switches to `moonshot-cn` provider, but still gets 401 because `moonshot-cn`
reads `KIMI_CN_API_KEY` — which is not set. The key is valid, the endpoint
is correct, but the env var name is wrong.

**Fix**: Either:
- Add `KIMI_CN_API_KEY=<same-key>` to `~/.hermes/.env`, OR
- Use `moonshot` provider with a base_url override:
  ```bash
  hermes config set auxiliary.vision.provider moonshot
  hermes config set auxiliary.vision.base_url https://api.moonshot.cn/v1
  ```

## Vision / Auxiliary Configuration

```bash
# Chinese user — key from platform.moonshot.cn/console
# IMPORTANT: also set KIMI_CN_API_KEY in .env (same key as KIMI_API_KEY)
hermes config set auxiliary.vision.provider moonshot-cn
hermes config set auxiliary.vision.model moonshot-v1-8k-vision-preview

# International user — key from platform.moonshot.ai
hermes config set auxiliary.vision.provider moonshot
hermes config set auxiliary.vision.model moonshot-v1-8k-vision-preview
```

After changing, `/reset` the session to pick up the new config.

## Troubleshooting 401 "Invalid Authentication"

### Quick Test: Run the diagnostic script

```bash
python scripts/check-moonshot-endpoint.py
```

This script (bundled with the skill under `scripts/`) tests your `KIMI_API_KEY`
against both endpoints and prints the recommended fix.

### Manual Test (if script unavailable)

```python
import os, json, urllib.request
from dotenv import load_dotenv
load_dotenv("~/.hermes/.env")

key = os.getenv("KIMI_API_KEY")
for endpoint, label in [
    ("https://api.moonshot.cn/v1/models", "中国站 (moonshot-cn)"),
    ("https://api.moonshot.ai/v1/models", "国际站 (moonshot)"),
]:
    try:
        req = urllib.request.Request(endpoint, headers={"Authorization": f"Bearer {key}"})
        resp = urllib.request.urlopen(req, timeout=10)
        data = json.loads(resp.read())
        print(f"✅ {label}: OK")
    except urllib.error.HTTPError as e:
        print(f"❌ {label}: HTTP {e.code} - {e.read().decode()[:200]}")
```

### Diagnostic Flow

1. **Confirm key works directly** — test both endpoints with raw HTTP. If the key works on one but not the other, it's an endpoint mismatch (not an expired key).
2. **Check what Hermes provider is configured** — `hermes config show | grep -A5 vision`
3. **Match provider to working endpoint** — if key works on `api.moonshot.cn`, use `moonshot-cn`. If it works on `api.moonshot.ai`, use `moonshot`.
4. **Apply fix** — `hermes config set auxiliary.vision.provider moonshot-cn` (or `moonshot`)

## Known Platform Issues

| 问题 | 影响 | 详见 |
|:---|:---|:---|
| Moonshot 端点不匹配 | 国际站 key 用在中国站 provider 会 401 | 见上方 Troubleshooting |
| WeChat iLink 限流 | 多段消息触发 429，导致部分消息丢失 | [`references/ilink-rate-limiting.md`](references/ilink-rate-limiting.md) |

## Related Skills

- `china-dev-proxy-setup` — proxy configuration for dual-network environments
- `hermes-agent` — general Hermes configuration (protected/bundled)
