---
name: hermes-telegram-delivery
description: "Use when Telegram 消息丢失/只收到几个字。诊断 gateway.log，Bot API 补发。"
category: productivity
tags: [hermes, telegram, delivery, debugging, send_path_degraded]
---

# Hermes Telegram 投递可靠性与补发

主通信平台的投递排障（微信 iLink 已弃用，历史见 `hermes-wechat-delivery`）。

## 第一诊断规则（最重要）

Telegram 上「长回复只收到几个字 / 开头片段」**≠ 内容被截断**。
真实语义 = **整条投递失败 + 流式预览残留**（预览消息编辑失败，停在最早推送的片段）。
行动顺序：先 grep gateway.log 查发送结果，再谈分块/长度。

关键日志模式（gateway.log）：

```
[Telegram] Send failed (attempt 1/2, retrying in 2.4s): send_path_degraded
[Telegram] Send failed (attempt 2/2, retrying in 4.4s): send_path_degraded
ERROR [Telegram] Failed to deliver response after 2 retries: send_path_degraded
[Telegram] Transient network error editing message <id>  ← 预览残留，误导用户以为"截断"
```

前置信号：最近几分钟多条 `Telegram network error (attempt 1/10) ... httpx.ConnectError` 或 `polling degraded` → 线路抖动中，此时长回复极易整条丢。

## 根因

`send_path_degraded` 重试仅 2 次、总窗口约 7s **< 线路抖动恢复 20-40s** → 整条丢弃。（2026-09-03 首次记录，网关侧重试窗口至今未调大；抖动期内发出的大消息必丢。）

## 补发（绕开网关，直连 Bot API）

`scripts/tg_resend.py` 可复用：

```bash
python tg_resend.py <msgs.json> [chat_id]
# msgs.json = JSON 字符串数组，每条一条消息；chat_id 缺省取 .env 的 TELEGRAM_HOME_CHANNEL
```

要点与坑：
1. **token 从 `~/AppData/Local/hermes/.env` 的 `TELEGRAM_BOT_TOKEN` 读**。config.yaml 里的 `telegram.token` 是残缺占位符（14 字符），直调 API 返回 404——勿用。
2. 走代理 `http://127.0.0.1:10808`（`HERMES_TG_PROXY` 可覆盖）。
3. 补发本身也撞抖动（`SSL: UNEXPECTED_EOF_WHILE_READING`），脚本已带 10 次重试 / 4s 间隔。
4. `parse_mode=HTML`（比 MarkdownV2 省事），文本里的 `& < >` 要转义。
5. 长回复拆 3-4 条（≤1500 字/条），单条失败只损失一块，不会整条丢。

## 诊断步骤速查

1. 用户报「只收到几个字」→ `grep -E "Failed to deliver|send_path_degraded|editing message" gateway.log | tail`
2. 确认 `send_path_degraded` → 按上面补发
3. 顺带看最近是否连续 ConnectError，判断抖动是否还在持续，决定补发时机
4. 复盘归档到 `D:\Workspace\Projects\Hermes运维\`，文件名 `复盘_YYYY-MM-DD_主题.md`

## 支持文件

- `references/telegram-delivery-debug.md` — 2026-09-15 实战：症状→语义对照、日志证据、补发坑位
- `scripts/tg_resend.py` — 直连 Bot API 补发脚本（每次现用现跑，勿手写）

## 待改进（多次记录未落地）

- 网关 `send_path_degraded` 重试窗口应提到覆盖 20-40s 抖动期（当前 ~7s 太短）。
